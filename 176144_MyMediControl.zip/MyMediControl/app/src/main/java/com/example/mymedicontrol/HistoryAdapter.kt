package com.example.mymedicontrol


import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView

import java.text.SimpleDateFormat
import java.util.*

class HistoryAdapter(private var historyItems: List<HistoryItem>) :
    RecyclerView.Adapter<HistoryAdapter.HistoryViewHolder>() {

    private val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())

    class HistoryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val cardHistory: CardView = itemView.findViewById(R.id.cardHistory)
        val ivIcon: ImageView = itemView.findViewById(R.id.ivIcon)
        val tvTitle: TextView = itemView.findViewById(R.id.tvTitle)
        val tvValue: TextView = itemView.findViewById(R.id.tvValue)
        val tvDate: TextView = itemView.findViewById(R.id.tvDate)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistoryViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_history, parent, false)
        return HistoryViewHolder(view)
    }

    override fun onBindViewHolder(holder: HistoryViewHolder, position: Int) {
        val item = historyItems[position]

        holder.tvTitle.text = item.title
        holder.tvValue.text = item.value
        holder.tvDate.text = dateFormat.format(item.date)

        // Configurar icono según el tipo
        val iconResource = when (item.type) {
            HistoryType.MEDICATION -> R.drawable.ic_medication
            HistoryType.GLUCOSE -> R.drawable.ic_glucose
            HistoryType.BLOOD_PRESSURE -> R.drawable.ic_blood_pressure
            HistoryType.WEIGHT -> R.drawable.ic_weight
            else -> R.drawable.ic_other
        }
        holder.ivIcon.setImageResource(iconResource)

        // Configurar color según el estado
        val colorResource = when (item.status) {
            HistoryStatus.NORMAL -> R.color.colorNormal
            HistoryStatus.COMPLETED -> R.color.colorCompleted
            HistoryStatus.MISSED -> R.color.colorMissed
            HistoryStatus.ALERT -> R.color.colorAlert
            HistoryStatus.DANGER -> R.color.colorDanger
        }

        val color = ContextCompat.getColor(holder.cardHistory.context, colorResource)
        holder.cardHistory.setCardBackgroundColor(color)
    }

    override fun getItemCount(): Int = historyItems.size

    fun updateData(newItems: List<HistoryItem>) {
        historyItems = newItems
        notifyDataSetChanged()
    }
}