package com.example.mymedicontrol

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.widget.Toolbar
import com.google.android.material.textfield.TextInputEditText
import java.text.SimpleDateFormat
import java.util.*

class MeasurementsActivity : AppCompatActivity() {

    private val TAG = "MeasurementsActivity" // Tag para logs

    private lateinit var toolbar: Toolbar
    private lateinit var rgMeasurementType: RadioGroup
    private lateinit var llGlucose: LinearLayout
    private lateinit var llPressure: LinearLayout
    private lateinit var llWeight: LinearLayout

    // Campos de glucosa
    private lateinit var etGlucoseValue: TextInputEditText
    private lateinit var spinnerGlucoseMoment: Spinner

    // Campos de presión arterial
    private lateinit var etSystolic: TextInputEditText
    private lateinit var etDiastolic: TextInputEditText
    private lateinit var etPulse: TextInputEditText

    // Campos de peso
    private lateinit var etWeight: TextInputEditText

    // Campos comunes
    private lateinit var etNotes: TextInputEditText
    private lateinit var tvDateTime: TextView
    private lateinit var btnChangeDateTime: Button
    private lateinit var btnSaveMeasurement: Button

    private val calendar = Calendar.getInstance()
    private lateinit var measurementDataSource: MeasurementDataSource

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_measurements)

        try {
            Log.d(TAG, "Iniciando MeasurementsActivity")

            // Inicializar las vistas
            initializeViews()

            // Inicializar la fuente de datos
            initializeDataSource()

            // Configurar toolbar
            setupToolbar()

            // Configurar spinner de momentos para glucosa
            setupGlucoseMomentSpinner()

            // Configurar fecha y hora actual
            updateDateTimeText()

            // Configurar listeners
            setupListeners()

            // Configuración inicial del tipo de medición
            rgMeasurementType.check(R.id.rbGlucose)

            Log.d(TAG, "MeasurementsActivity inicializada correctamente")
        } catch (e: Exception) {
            // Si ocurre algún error durante la inicialización
            Log.e(TAG, "Error en onCreate: ${e.message}", e)
            Toast.makeText(this, "Error al inicializar: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun initializeViews() {
        Log.d(TAG, "Inicializando vistas")

        // Inicializar vistas
        toolbar = findViewById(R.id.toolbar)
        rgMeasurementType = findViewById(R.id.rgMeasurementType)
        llGlucose = findViewById(R.id.llGlucose)
        llPressure = findViewById(R.id.llPressure)
        llWeight = findViewById(R.id.llWeight)

        // Campos de glucosa
        etGlucoseValue = findViewById(R.id.etGlucoseValue)
        spinnerGlucoseMoment = findViewById(R.id.spinnerGlucoseMoment)

        // Campos de presión arterial
        etSystolic = findViewById(R.id.etSystolic)
        etDiastolic = findViewById(R.id.etDiastolic)
        etPulse = findViewById(R.id.etPulse)

        // Campos de peso
        etWeight = findViewById(R.id.etWeight)

        // Campos comunes
        etNotes = findViewById(R.id.etNotes)
        tvDateTime = findViewById(R.id.tvDateTime)
        btnChangeDateTime = findViewById(R.id.btnChangeDateTime)
        btnSaveMeasurement = findViewById(R.id.btnSaveMeasurement)

        Log.d(TAG, "Vistas inicializadas correctamente")
    }

    private fun initializeDataSource() {
        try {
            Log.d(TAG, "Inicializando fuente de datos")
            measurementDataSource = MeasurementDataSource(this)
            Log.d(TAG, "Fuente de datos inicializada correctamente")
        } catch (e: Exception) {
            Log.e(TAG, "Error al inicializar la fuente de datos: ${e.message}", e)
            Toast.makeText(this, "Error al conectar con la base de datos: ${e.message}", Toast.LENGTH_LONG).show()
            throw e  // Re-lanzar la excepción para manejarla en el bloque try-catch principal
        }
    }

    private fun setupToolbar() {
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
    }

    private fun setupGlucoseMomentSpinner() {
        try {
            Log.d(TAG, "Configurando spinner de glucosa")

            val moments = arrayOf(
                "En ayunas",
                "Antes de desayunar",
                "Después de desayunar",
                "Antes de almorzar",
                "Después de almorzar",
                "Antes de cenar",
                "Después de cenar",
                "Antes de dormir"
            )
            val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, moments)
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinnerGlucoseMoment.adapter = adapter

            Log.d(TAG, "Spinner configurado correctamente")
        } catch (e: Exception) {
            Log.e(TAG, "Error al configurar spinner: ${e.message}", e)
            Toast.makeText(this, "Error al configurar opciones de glucosa", Toast.LENGTH_SHORT).show()
        }
    }

    private fun updateDateTimeText() {
        val dateFormat = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault())
        tvDateTime.text = "Fecha y hora: ${dateFormat.format(calendar.time)}"
        Log.d(TAG, "Fecha/hora actualizada: ${dateFormat.format(calendar.time)}")
    }

    private fun setupListeners() {
        // Radio Group para cambiar el tipo de medición
        rgMeasurementType.setOnCheckedChangeListener { _, checkedId ->
            try {
                Log.d(TAG, "Tipo de medición cambiado a ID: $checkedId")

                when (checkedId) {
                    R.id.rbGlucose -> {
                        llGlucose.visibility = View.VISIBLE
                        llPressure.visibility = View.GONE
                        llWeight.visibility = View.GONE
                        Log.d(TAG, "Seleccionado: Glucosa")
                    }
                    R.id.rbPressure -> {
                        llGlucose.visibility = View.GONE
                        llPressure.visibility = View.VISIBLE
                        llWeight.visibility = View.GONE
                        Log.d(TAG, "Seleccionado: Presión arterial")
                    }
                    R.id.rbWeight -> {
                        llGlucose.visibility = View.GONE
                        llPressure.visibility = View.GONE
                        llWeight.visibility = View.VISIBLE
                        Log.d(TAG, "Seleccionado: Peso")
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error al cambiar tipo de medición: ${e.message}", e)
            }
        }

        // Botón para cambiar fecha y hora
        btnChangeDateTime.setOnClickListener {
            showDateTimePickerDialog()
        }

        // Botón para guardar la medición
        btnSaveMeasurement.setOnClickListener {
            try {
                Log.d(TAG, "Botón guardar presionado")
                saveMeasurement()
            } catch (e: Exception) {
                Log.e(TAG, "Error al guardar medición: ${e.message}", e)
                Toast.makeText(
                    this,
                    "Error al guardar: ${e.message}",
                    Toast.LENGTH_LONG
                ).show()
            }
        }
    }

    private fun showDateTimePickerDialog() {
        try {
            // Mostrar selector de fecha
            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val day = calendar.get(Calendar.DAY_OF_MONTH)

            Log.d(TAG, "Mostrando selector de fecha")
            DatePickerDialog(this, { _, selectedYear, selectedMonth, selectedDay ->
                calendar.set(Calendar.YEAR, selectedYear)
                calendar.set(Calendar.MONTH, selectedMonth)
                calendar.set(Calendar.DAY_OF_MONTH, selectedDay)

                Log.d(TAG, "Fecha seleccionada: $selectedDay/${selectedMonth+1}/$selectedYear")

                // Después de seleccionar la fecha, mostrar selector de hora
                showTimePickerDialog()
            }, year, month, day).show()
        } catch (e: Exception) {
            Log.e(TAG, "Error al mostrar selector de fecha: ${e.message}", e)
            Toast.makeText(this, "Error al abrir selector de fecha", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showTimePickerDialog() {
        try {
            val hour = calendar.get(Calendar.HOUR_OF_DAY)
            val minute = calendar.get(Calendar.MINUTE)

            Log.d(TAG, "Mostrando selector de hora")
            TimePickerDialog(this, { _, selectedHour, selectedMinute ->
                calendar.set(Calendar.HOUR_OF_DAY, selectedHour)
                calendar.set(Calendar.MINUTE, selectedMinute)

                Log.d(TAG, "Hora seleccionada: $selectedHour:$selectedMinute")

                // Actualizar el texto con la fecha y hora seleccionadas
                updateDateTimeText()
            }, hour, minute, true).show()
        } catch (e: Exception) {
            Log.e(TAG, "Error al mostrar selector de hora: ${e.message}", e)
            Toast.makeText(this, "Error al abrir selector de hora", Toast.LENGTH_SHORT).show()
        }
    }

    private fun saveMeasurement() {
        // Log para debug
        Log.d(TAG, "Iniciando guardado de medición")

        // Obtener valores según el tipo de medición
        val measurementType: String
        val value: String

        try {
            when (rgMeasurementType.checkedRadioButtonId) {
                R.id.rbGlucose -> {
                    val glucoseValue = etGlucoseValue.text.toString().trim()
                    if (glucoseValue.isEmpty()) {
                        Toast.makeText(this, "Ingresa el valor de glucosa", Toast.LENGTH_SHORT).show()
                        return
                    }
                    measurementType = "GLUCOSE"
                    value = glucoseValue
                    Log.d(TAG, "Tipo: Glucosa, Valor: $value")
                }
                R.id.rbPressure -> {
                    val systolic = etSystolic.text.toString().trim()
                    val diastolic = etDiastolic.text.toString().trim()
                    val pulse = etPulse.text.toString().trim()

                    if (systolic.isEmpty() || diastolic.isEmpty()) {
                        Toast.makeText(this, "Ingresa los valores de presión arterial", Toast.LENGTH_SHORT).show()
                        return
                    }
                    measurementType = "BLOOD_PRESSURE"
                    value = "$systolic/$diastolic"
                    Log.d(TAG, "Tipo: Presión, Valor: $value, Pulso: $pulse")
                }
                R.id.rbWeight -> {
                    val weightValue = etWeight.text.toString().trim()
                    if (weightValue.isEmpty()) {
                        Toast.makeText(this, "Ingresa el valor de peso", Toast.LENGTH_SHORT).show()
                        return
                    }
                    measurementType = "WEIGHT"
                    value = weightValue
                    Log.d(TAG, "Tipo: Peso, Valor: $value")
                }
                else -> {
                    Log.e(TAG, "Tipo de medición no seleccionado")
                    Toast.makeText(this, "Selecciona un tipo de medición", Toast.LENGTH_SHORT).show()
                    return
                }
            }

            // Obtener notas y momento de la medición
            val notes = etNotes.text.toString().trim()
            val moment = if (measurementType == "GLUCOSE") {
                spinnerGlucoseMoment.selectedItem.toString()
            } else {
                ""
            }

            // Log para verificar fecha
            val simpleDateFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
            Log.d(TAG, "Fecha y hora: ${simpleDateFormat.format(calendar.time)}")

            // Crear objeto de medición
            val fullNotes = if (moment.isEmpty()) notes else "$moment - $notes"
            Log.d(TAG, "Notas completas: $fullNotes")

            val measurement = Measurement(
                id = 0, // Se generará automáticamente
                type = measurementType,
                value = value,
                notes = fullNotes, // Nunca debe ser null para evitar problemas
                datetime = calendar.time,
                createdAt = Date()
            )

            Log.d(TAG, "Objeto Measurement creado: tipo=${measurement.type}, valor=${measurement.value}")

            // Guardar en la base de datos
            val id = measurementDataSource.insertMeasurement(measurement)
            Log.d(TAG, "Resultado de inserción: ID = $id")

            if (id > 0) {
                Toast.makeText(this, "Medición guardada correctamente", Toast.LENGTH_SHORT).show()
                finish()
            } else {
                Toast.makeText(this, "Error al guardar la medición: ID inválido", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error al procesar o guardar la medición: ${e.message}", e)
            Toast.makeText(
                this,
                "Error al guardar: ${e.message}",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressed()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onDestroy() {
        super.onDestroy()
        // Asegurarse de cerrar la conexión a la base de datos
        try {
            if (::measurementDataSource.isInitialized) {
                // Solo si la variable ha sido inicializada
                measurementDataSource.close()
                Log.d(TAG, "Conexión a base de datos cerrada correctamente")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error al cerrar la base de datos: ${e.message}", e)
        }
    }
}