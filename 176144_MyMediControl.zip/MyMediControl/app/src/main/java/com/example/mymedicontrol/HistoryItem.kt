package com.example.mymedicontrol



import java.util.Date

data class HistoryItem(
    val id: Long,
    val title: String,
    val value: String,
    val date: Date,
    val type: HistoryType,
    val status: HistoryStatus
)