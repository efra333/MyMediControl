package com.example.mymedicontrol

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import androidx.cardview.widget.CardView
import androidx.lifecycle.lifecycleScope

import com.google.firebase.auth.FirebaseAuth

import kotlinx.coroutines.launch
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.*

class DashboardActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar
    private lateinit var ivSettings: ImageView
    private lateinit var tvUserGreeting: TextView
    private lateinit var tvDate: TextView
    private lateinit var tvNextMedicationName: TextView
    private lateinit var tvNextMedicationTime: TextView
    private lateinit var btnConfirmMedication: Button
    private lateinit var cardMedications: CardView
    private lateinit var cardMeasurements: CardView
    private lateinit var cardHistory: CardView
    private lateinit var cardSettings: CardView

    // Nuevas variables para la sección de nutrición
    private lateinit var tvFoodName: TextView
    private lateinit var tvFoodBenefit: TextView
    private lateinit var tvNutritionInfo: TextView
    private lateinit var progressNutrition: ProgressBar
    private lateinit var btnGetNewFood: Button
    private lateinit var ivFoodIcon: ImageView

    private lateinit var auth: FirebaseAuth
    private lateinit var medicationDataSource: MedicationDataSource
    private lateinit var nutritionService: NutritionService
    private var currentMedication: Medication? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_dashboard)

        try {
            // Inicializar Firebase Auth
            auth = FirebaseAuth.getInstance()

            // Inicializar la fuente de datos de medicamentos
            medicationDataSource = MedicationDataSource(this)

            // Inicializar el servicio de nutrición
            nutritionService = NutritionService()

            // Verificar si el usuario está autenticado
            if (auth.currentUser == null) {
                startActivity(Intent(this, WelcomeActivity::class.java))
                finish()
                return
            }

            // Inicializar vistas
            toolbar = findViewById(R.id.toolbar)
            ivSettings = findViewById(R.id.ivSettings)
            tvUserGreeting = findViewById(R.id.tvUserGreeting)
            tvDate = findViewById(R.id.tvDate)
            tvNextMedicationName = findViewById(R.id.tvNextMedicationName)
            tvNextMedicationTime = findViewById(R.id.tvNextMedicationTime)
            btnConfirmMedication = findViewById(R.id.btnConfirmMedication)
            cardMedications = findViewById(R.id.cardMedications)
            cardMeasurements = findViewById(R.id.cardMeasurements)
            cardHistory = findViewById(R.id.cardHistory)
            cardSettings = findViewById(R.id.cardSettings)

            // Inicializar vistas de nutrición
            initializeNutritionViews()

            // Configurar toolbar
            setSupportActionBar(toolbar)

            // Mostrar datos del usuario
            setupUserInfo()

            // Mostrar fecha actual
            setupCurrentDate()

            // Cargar próximo medicamento
            loadNextMedication()

            // Cargar recomendación nutricional
            loadNutritionRecommendation()

            // Click listeners
            ivSettings.setOnClickListener {
                startActivity(Intent(this, SettingsActivity::class.java))
            }

            btnConfirmMedication.setOnClickListener {
                // Marcar medicamento como tomado
                markMedicationAsTaken()
            }

            btnGetNewFood.setOnClickListener {
                loadNutritionRecommendation()
            }

            cardMedications.setOnClickListener {
                startActivity(Intent(this, MedicationsActivity::class.java))
            }

            cardMeasurements.setOnClickListener {
                startActivity(Intent(this, MeasurementsActivity::class.java))
            }

            cardHistory.setOnClickListener {
                startActivity(Intent(this, HistoryActivity::class.java))
            }

            cardSettings.setOnClickListener {
                startActivity(Intent(this, SettingsActivity::class.java))
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Error al inicializar: ${e.message}", Toast.LENGTH_LONG).show()
            e.printStackTrace()
        }
    }

    private fun initializeNutritionViews() {
        tvFoodName = findViewById(R.id.tvFoodName)
        tvFoodBenefit = findViewById(R.id.tvFoodBenefit)
        tvNutritionInfo = findViewById(R.id.tvNutritionInfo)
        progressNutrition = findViewById(R.id.progressNutrition)
        btnGetNewFood = findViewById(R.id.btnGetNewFood)
        ivFoodIcon = findViewById(R.id.ivFoodIcon)
    }

    private fun setupUserInfo() {
        try {
            // Obtener nombre de usuario de SharedPreferences
            val preferences = getSharedPreferences("MediControlPrefs", MODE_PRIVATE)
            val userName = preferences.getString("userName", "Usuario")

            tvUserGreeting.text = "Hola, $userName"
        } catch (e: Exception) {
            tvUserGreeting.text = "Hola, Usuario"
            e.printStackTrace()
        }
    }

    private fun setupCurrentDate() {
        try {
            val dateFormat = SimpleDateFormat("EEEE, d 'de' MMMM", Locale("es", "ES"))
            val currentDate = dateFormat.format(Date())
            tvDate.text = currentDate
        } catch (e: Exception) {
            tvDate.text = ""
            e.printStackTrace()
        }
    }

    private fun loadNextMedication() {
        try {
            Log.d("DashboardActivity", "Cargando próximo medicamento")

            // Obtener el próximo medicamento programado
            val medication = medicationDataSource.getNextMedication()

            // Si no hay medicamentos programados
            if (medication == null) {
                Log.d("DashboardActivity", "No hay medicamentos programados")
                tvNextMedicationName.text = "No hay medicamentos programados"
                tvNextMedicationTime.text = ""
                btnConfirmMedication.visibility = View.GONE
                currentMedication = null
                return
            }

            // Establecer el medicamento actual
            currentMedication = medication

            // Mostrar información del medicamento
            tvNextMedicationName.text = "${medication.name} ${medication.dose}"

            val dateFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
            val nextDoseTime = medication.nextDose?.let { dateFormat.format(it) } ?: "No programado"
            tvNextMedicationTime.text = "Hoy a las $nextDoseTime"

            // Comprobar si ya es hora de tomar el medicamento
            val currentTime = System.currentTimeMillis()
            val medicationTime = medication.nextDose?.time ?: 0

            // Añadir log para depuración
            Log.d("DashboardActivity", "Hora actual: ${Date(currentTime)}")
            Log.d("DashboardActivity", "Hora medicamento: ${medication.nextDose}")
            Log.d("DashboardActivity", "¿Es hora? ${medicationTime <= currentTime}")

            // Verificar dosis tomadas
            val doses = medicationDataSource.getMedicationDoses(medication.id)
            Log.d("DashboardActivity", "Dosis registradas: ${doses.size}")

            for (dose in doses) {
                Log.d("DashboardActivity", "Dosis: ${dose.status}, programada: ${dose.scheduled}, tomada: ${dose.takenAt}")
            }

            // Verificar si ya se tomó este medicamento para esta dosis programada
            val alreadyTaken = doses.any { dose ->
                val isSameTime = sameScheduledTime(dose.scheduled, medication.nextDose)
                val isTaken = dose.status == "TAKEN"  // Solo considerar dosis con estado TAKEN
                Log.d("DashboardActivity", "Comparando ${dose.scheduled} con ${medication.nextDose}: $isSameTime, estado TAKEN: $isTaken")
                isSameTime && isTaken
            }

            if (alreadyTaken) {
                // Si ya se tomó esta dosis, no mostrar el botón
                Log.d("DashboardActivity", "Esta dosis ya fue tomada con estado TAKEN, ocultando botón")
                btnConfirmMedication.visibility = View.GONE
            } else {
                // Mostrar el botón solo si ya es hora (actual >= programada)
                if (medicationTime <= currentTime) {
                    Log.d("DashboardActivity", "Es hora de tomar este medicamento, mostrando botón")
                    btnConfirmMedication.visibility = View.VISIBLE
                } else {
                    Log.d("DashboardActivity", "Aún no es hora de tomar este medicamento, ocultando botón")
                    btnConfirmMedication.visibility = View.GONE
                }
            }

        } catch (e: Exception) {
            Log.e("DashboardActivity", "Error al cargar medicamentos", e)
            tvNextMedicationName.text = "Error al cargar medicamentos"
            tvNextMedicationTime.text = ""
            btnConfirmMedication.visibility = View.GONE
            e.printStackTrace()
        }
    }

    private fun loadNutritionRecommendation() {
        try {
            // Mostrar progreso y ocultar información
            progressNutrition.visibility = View.VISIBLE
            tvNutritionInfo.text = ""
            btnGetNewFood.isEnabled = false

            // Determinar tipo de medicamento para personalizar recomendación
            val medicationType = currentMedication?.type?.toString()

            // Obtener alimento aleatorio
            val randomFood = nutritionService.getRandomHealthyFood()

            // Obtener beneficio para este tipo de medicamento
            val benefit = nutritionService.getFoodBenefit(randomFood, medicationType)

            // Obtener nombre en español
            val spanishFoodName = getSpanishFoodName(randomFood)

            // Actualizar UI con nombre y beneficio
            tvFoodName.text = spanishFoodName
            tvFoodBenefit.text = benefit

            // Actualizar icono
            ivFoodIcon.setImageResource(FoodIconHelper.getIconResourceForFood(randomFood))

            // Consultar API en segundo plano
            lifecycleScope.launch {
                try {
                    val nutritionInfo = nutritionService.getNutritionInfo(randomFood)

                    if (nutritionInfo.items.isNotEmpty()) {
                        val item = nutritionInfo.items[0]
                        val df = DecimalFormat("#.##")

                        // Actualizar UI con información nutricional
                        val nutritionText = StringBuilder()
                        nutritionText.append("Por 100g:")
                        nutritionText.append("\n• Calorías: ${df.format(item.calories)} kcal")
                        nutritionText.append("\n• Proteínas: ${df.format(item.protein_g)}g")
                        nutritionText.append("\n• Carbohidratos: ${df.format(item.carbohydrates_total_g)}g")
                        nutritionText.append("\n• Grasas: ${df.format(item.fat_total_g)}g")

                        // Añadir información adicional según tipo de medicamento
                        when {
                            medicationType?.contains("DIABETES", ignoreCase = true) == true -> {
                                nutritionText.append("\n• Fibra: ${df.format(item.fiber_g)}g")
                                nutritionText.append("\n• Azúcares: ${df.format(item.sugar_g)}g")
                            }
                            medicationType?.contains("PRESSURE", ignoreCase = true) == true ||
                                    medicationType?.contains("HYPERTENSION", ignoreCase = true) == true -> {
                                nutritionText.append("\n• Sodio: ${df.format(item.sodium_mg)}mg")
                                nutritionText.append("\n• Potasio: ${df.format(item.potassium_mg)}mg")
                            }
                            medicationType?.contains("CHOLESTEROL", ignoreCase = true) == true -> {
                                nutritionText.append("\n• Grasas saturadas: ${df.format(item.fat_saturated_g)}g")
                                nutritionText.append("\n• Colesterol: ${df.format(item.cholesterol_mg)}mg")
                            }
                        }

                        tvNutritionInfo.text = nutritionText.toString()
                    } else {
                        tvNutritionInfo.text = "No se pudo obtener información nutricional detallada."
                    }
                } catch (e: Exception) {
                    Log.e("DashboardActivity", "Error al cargar información nutricional", e)
                    tvNutritionInfo.text = "Error al cargar información: ${e.message}"
                } finally {
                    // Ocultar progreso y habilitar botón
                    progressNutrition.visibility = View.GONE
                    btnGetNewFood.isEnabled = true
                }
            }
        } catch (e: Exception) {
            Log.e("DashboardActivity", "Error al cargar recomendación", e)
            tvNutritionInfo.text = "Error al cargar recomendación: ${e.message}"
            progressNutrition.visibility = View.GONE
            btnGetNewFood.isEnabled = true
        }
    }

    // Traductor simple para nombres de alimentos
    private fun getSpanishFoodName(englishName: String): String {
        return when (englishName) {
            "banana" -> "Plátano"
            "spinach" -> "Espinaca"
            "apple" -> "Manzana"
            "avocado" -> "Aguacate"
            "salmon" -> "Salmón"
            "broccoli" -> "Brócoli"
            "blueberries" -> "Arándanos"
            "chicken breast" -> "Pechuga de pollo"
            "oats" -> "Avena"
            "almonds" -> "Almendras"
            "greek yogurt" -> "Yogur griego"
            "oranges" -> "Naranjas"
            "sweet potato" -> "Camote"
            "lentils" -> "Lentejas"
            "kiwi" -> "Kiwi"
            "eggs" -> "Huevos"
            "quinoa" -> "Quinoa"
            "tomato" -> "Tomate"
            "kale" -> "Col rizada"
            "walnuts" -> "Nueces"
            else -> englishName.capitalize()
        }
    }

    /**
     * Compara dos fechas para determinar si corresponden a la misma dosis programada
     * Ignora segundos y milisegundos para la comparación
     */
    private fun sameScheduledTime(date1: Date?, date2: Date?): Boolean {
        if (date1 == null || date2 == null) return false

        val cal1 = Calendar.getInstance()
        cal1.time = date1
        cal1.set(Calendar.SECOND, 0)
        cal1.set(Calendar.MILLISECOND, 0)

        val cal2 = Calendar.getInstance()
        cal2.time = date2
        cal2.set(Calendar.SECOND, 0)
        cal2.set(Calendar.MILLISECOND, 0)

        // Comparamos año, mes, día, hora y minuto
        return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                cal1.get(Calendar.MONTH) == cal2.get(Calendar.MONTH) &&
                cal1.get(Calendar.DAY_OF_MONTH) == cal2.get(Calendar.DAY_OF_MONTH) &&
                cal1.get(Calendar.HOUR_OF_DAY) == cal2.get(Calendar.HOUR_OF_DAY) &&
                cal1.get(Calendar.MINUTE) == cal2.get(Calendar.MINUTE)
    }

    private fun markMedicationAsTaken() {
        try {
            // Marcar el medicamento como tomado y actualizar la próxima dosis
            currentMedication?.let { medication ->
                Log.d("DashboardActivity", "Confirmando medicamento: ${medication.name}")

                // Calculamos la fecha/hora actual
                val currentTime = Date()

                // Obtenemos la fecha programada (o usamos la actual si no hay)
                val scheduledTime = medication.nextDose ?: currentTime

                // Registramos la dosis como tomada (ahora el método comprueba si ya existe una dosis programada)
                val doseId = medicationDataSource.recordMedicationDose(
                    medicationId = medication.id,
                    doseDate = scheduledTime,
                    status = "TAKEN"
                )

                if (doseId > 0) {
                    // Calcular la próxima dosis (en este ejemplo, +24 horas)
                    val calendar = Calendar.getInstance()
                    calendar.time = scheduledTime
                    calendar.add(Calendar.HOUR_OF_DAY, 24)
                    val nextDose = calendar.time

                    // Actualizar la próxima dosis en la base de datos
                    medicationDataSource.updateNextDose(medication.id, nextDose)

                    // Actualizar la UI
                    tvNextMedicationName.text = "¡Medicamento confirmado!"
                    val dateFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
                    tvNextMedicationTime.text = "Próximo: Mañana ${dateFormat.format(nextDose)}"
                    btnConfirmMedication.visibility = View.GONE

                    Toast.makeText(this, "Medicamento marcado como tomado", Toast.LENGTH_SHORT).show()

                    Log.d("DashboardActivity", "Medicamento confirmado exitosamente")

                    // Recargar recomendaciones nutricionales según el medicamento que se tomó
                    loadNutritionRecommendation()

                    // Recargar para mostrar el siguiente medicamento si hay alguno
                    // Damos un pequeño retraso para que el usuario pueda ver el mensaje de confirmación
                    tvNextMedicationName.postDelayed({
                        loadNextMedication()
                    }, 3000) // 3 segundos de retraso

                } else {
                    Toast.makeText(this, "Error al registrar la dosis", Toast.LENGTH_SHORT).show()
                    Log.e("DashboardActivity", "Error al registrar la dosis, ID retornado: $doseId")
                }
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Error al confirmar medicamento: ${e.message}", Toast.LENGTH_SHORT).show()
            Log.e("DashboardActivity", "Error al confirmar medicamento", e)
            e.printStackTrace()
        }
    }

    override fun onResume() {
        super.onResume()

        // Recargar datos en caso de que hayan cambiado en otra pantalla
        Log.d("DashboardActivity", "onResume llamado, recargando datos")
        loadNextMedication()

        // También recargamos las recomendaciones nutricionales
        if (::nutritionService.isInitialized) {
            loadNutritionRecommendation()
        }
    }
}