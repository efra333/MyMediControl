// app/src/main/java/com/example/mymedicontrol/FoodIconHelper.kt
package com.example.mymedicontrol

/**
 * Clase utilitaria para manejar iconos de alimentos
 */
object FoodIconHelper {

    /**
     * Obtiene el recurso de icono para un alimento específico
     */
    fun getIconResourceForFood(foodName: String): Int {
        // Devuelve el icono correspondiente según el nombre del alimento
        return when (foodName.lowercase()) {
            "banana" -> R.drawable.ic_food
            "apple" -> R.drawable.ic_food
            "spinach" -> R.drawable.ic_food
            "avocado" -> R.drawable.ic_food
            "salmon" -> R.drawable.ic_food
            "broccoli" -> R.drawable.ic_food
            "blueberries" -> R.drawable.ic_food
            "chicken breast" -> R.drawable.ic_food
            "oats" -> R.drawable.ic_food
            "almonds" -> R.drawable.ic_food
            "greek yogurt" -> R.drawable.ic_food
            "oranges" -> R.drawable.ic_food
            "sweet potato" -> R.drawable.ic_food
            "lentils" -> R.drawable.ic_food
            "kiwi" -> R.drawable.ic_food
            "eggs" -> R.drawable.ic_food
            "quinoa" -> R.drawable.ic_food
            "tomato" -> R.drawable.ic_food
            "kale" -> R.drawable.ic_food
            "walnuts" -> R.drawable.ic_food
            else -> R.drawable.ic_food
        }
        // Nota: Estamos usando el mismo icono (ic_food) para todos los alimentos por simplicidad
        // Puedes reemplazar cada línea con iconos específicos cuando los tengas disponibles
    }
}