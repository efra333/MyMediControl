package com.example.mymedicontrol



enum class HistoryType {
    MEDICATION,
    GLUCOSE,
    BLOOD_PRESSURE,
    WEIGHT,
    OTHER
}