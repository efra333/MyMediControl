package com.example.mymedicontrol

import android.app.ProgressDialog
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.SwitchCompat
import androidx.appcompat.widget.Toolbar

import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest
import com.google.firebase.firestore.FirebaseFirestore

class SettingsActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar
    private lateinit var tvUserName: TextView
    private lateinit var tvUserEmail: TextView
    private lateinit var tvUserCondition: TextView
    private lateinit var btnEditProfile: Button
    private lateinit var switchMedicationReminders: SwitchCompat
    private lateinit var switchMeasurementReminders: SwitchCompat
    private lateinit var switchAlerts: SwitchCompat
    private lateinit var spinnerGlucoseUnit: Spinner
    private lateinit var spinnerWeightUnit: Spinner
    private lateinit var btnExportData: Button
    private lateinit var btnClearData: Button
    private lateinit var btnLogout: Button

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private lateinit var dbHelper: MediControlDbHelper
    private lateinit var measurementDataSource: MeasurementDataSource

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)

        try {
            // Inicializar Firebase
            FirebaseApp.initializeApp(this)
            auth = FirebaseAuth.getInstance()
            db = FirebaseFirestore.getInstance()

            // Inicializar DB Helper y DataSources
            dbHelper = MediControlDbHelper(this)
            measurementDataSource = MeasurementDataSource(this)

            // Inicializar vistas
            initializeViews()

            // Configurar toolbar
            setSupportActionBar(toolbar)
            supportActionBar?.setDisplayHomeAsUpEnabled(true)

            // Cargar datos del usuario
            loadUserData()

            // Configurar spinners
            setupSpinners()

            // Cargar estado de los switches
            loadSwitchStates()

            // Click listeners
            setupClickListeners()
        } catch (e: Exception) {
            Toast.makeText(this, "Error al inicializar: ${e.message}", Toast.LENGTH_LONG).show()
            e.printStackTrace()
        }
    }

    private fun initializeViews() {
        toolbar = findViewById(R.id.toolbar)
        tvUserName = findViewById(R.id.tvUserName)
        tvUserEmail = findViewById(R.id.tvUserEmail)
        tvUserCondition = findViewById(R.id.tvUserCondition)
        btnEditProfile = findViewById(R.id.btnEditProfile)
        switchMedicationReminders = findViewById(R.id.switchMedicationReminders)
        switchMeasurementReminders = findViewById(R.id.switchMeasurementReminders)
        switchAlerts = findViewById(R.id.switchAlerts)
        spinnerGlucoseUnit = findViewById(R.id.spinnerGlucoseUnit)
        spinnerWeightUnit = findViewById(R.id.spinnerWeightUnit)
        btnExportData = findViewById(R.id.btnExportData)
        btnClearData = findViewById(R.id.btnClearData)
        btnLogout = findViewById(R.id.btnLogout)
    }

    private fun loadUserData() {
        val currentUser = auth.currentUser

        if (currentUser != null) {
            // Cargar datos básicos de Firebase Auth
            tvUserEmail.text = currentUser.email ?: "No disponible"

            // Intentar obtener nombre de Firebase Auth primero
            var userName = currentUser.displayName

            // Cargar datos completos desde Firestore
            db.collection("users").document(currentUser.uid)
                .get()
                .addOnSuccessListener { document ->
                    if (document != null && document.exists()) {
                        // Si tenemos datos en Firestore, usamos esos
                        userName = document.getString("name") ?: userName ?: "Usuario"
                        val userCondition = document.getString("condition") ?: "No especificada"

                        // Actualizar UI
                        tvUserName.text = userName
                        tvUserCondition.text = "Condición: $userCondition"

                        // Guardar en SharedPreferences para acceso rápido
                        val preferences = getSharedPreferences("MediControlPrefs", MODE_PRIVATE)
                        val editor = preferences.edit()
                        editor.putString("userName", userName)
                        editor.putString("userCondition", userCondition)
                        editor.apply()
                    } else {
                        // Si no hay datos en Firestore, usar SharedPreferences
                        loadUserDataFromPreferences()
                    }
                }
                .addOnFailureListener { e ->
                    // En caso de error, usar SharedPreferences
                    Toast.makeText(this, "Error al cargar datos de Firestore: ${e.message}", Toast.LENGTH_SHORT).show()
                    loadUserDataFromPreferences()
                }
        } else {
            // Manejar el caso en que el usuario no esté autenticado
            Toast.makeText(this, "No hay sesión activa", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, WelcomeActivity::class.java)
            startActivity(intent)
            finish()
        }
    }

    private fun loadUserDataFromPreferences() {
        val preferences = getSharedPreferences("MediControlPrefs", MODE_PRIVATE)
        val userName = preferences.getString("userName", "Usuario")
        val userCondition = preferences.getString("userCondition", "No especificada")

        tvUserName.text = userName
        tvUserCondition.text = "Condición: $userCondition"
    }

    private fun loadSwitchStates() {
        val preferences = getSharedPreferences("MediControlPrefs", MODE_PRIVATE)
        switchMedicationReminders.isChecked = preferences.getBoolean("medicationReminders", true)
        switchMeasurementReminders.isChecked = preferences.getBoolean("measurementReminders", true)
        switchAlerts.isChecked = preferences.getBoolean("alerts", true)
    }

    private fun setupSpinners() {
        // Spinner de unidades de glucosa
        val glucoseUnits = arrayOf("mg/dL", "mmol/L")
        val glucoseAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, glucoseUnits)
        glucoseAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerGlucoseUnit.adapter = glucoseAdapter

        // Spinner de unidades de peso
        val weightUnits = arrayOf("kg", "lb")
        val weightAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, weightUnits)
        weightAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerWeightUnit.adapter = weightAdapter

        // Seleccionar unidades guardadas previamente
        val preferences = getSharedPreferences("MediControlPrefs", MODE_PRIVATE)
        val glucoseUnitIndex = preferences.getInt("glucoseUnitIndex", 0)
        val weightUnitIndex = preferences.getInt("weightUnitIndex", 0)

        spinnerGlucoseUnit.setSelection(glucoseUnitIndex)
        spinnerWeightUnit.setSelection(weightUnitIndex)
    }

    private fun setupClickListeners() {
        // Botón de editar perfil
        btnEditProfile.setOnClickListener {
            showEditProfileDialog()
        }

        // Cambios en switches de notificaciones
        switchMedicationReminders.setOnCheckedChangeListener { _, isChecked ->
            saveSwitchState("medicationReminders", isChecked)
        }

        switchMeasurementReminders.setOnCheckedChangeListener { _, isChecked ->
            saveSwitchState("measurementReminders", isChecked)
        }

        switchAlerts.setOnCheckedChangeListener { _, isChecked ->
            saveSwitchState("alerts", isChecked)
        }

        // Cambios en spinners de unidades
        spinnerGlucoseUnit.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                saveSpinnerSelection("glucoseUnitIndex", position)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        spinnerWeightUnit.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                saveSpinnerSelection("weightUnitIndex", position)
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }

        // Botón de exportar datos
        btnExportData.setOnClickListener {
            Toast.makeText(this, "Exportando datos...", Toast.LENGTH_SHORT).show()
            // En una implementación real, exportarías todos los datos de la base de datos
        }

        // Botón de borrar datos
        btnClearData.setOnClickListener {
            showClearDataConfirmationDialog()
        }

        // Botón de cerrar sesión
        btnLogout.setOnClickListener {
            showLogoutConfirmationDialog()
        }
    }

    private fun showEditProfileDialog() {
        // Inflar el layout para el diálogo
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_edit_profile, null)

        // Obtener referencias a los campos del diálogo
        val etName = dialogView.findViewById<EditText>(R.id.etName)
        val etCondition = dialogView.findViewById<EditText>(R.id.etCondition)

        // Cargar datos actuales
        val preferences = getSharedPreferences("MediControlPrefs", MODE_PRIVATE)
        val currentName = preferences.getString("userName", "Usuario")
        val currentCondition = preferences.getString("userCondition", "No especificada")

        // Establecer valores actuales en los campos
        etName.setText(currentName)
        etCondition.setText(currentCondition)

        // Construir y mostrar el diálogo
        AlertDialog.Builder(this)
            .setTitle("Editar Perfil")
            .setView(dialogView)
            .setPositiveButton("Guardar") { _, _ ->
                // Obtener nuevos valores
                val newName = etName.text.toString().trim()
                val newCondition = etCondition.text.toString().trim()

                // Validar que no estén vacíos
                if (newName.isEmpty()) {
                    Toast.makeText(this, "El nombre no puede estar vacío", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }

                // Mostrar progreso
                val progressDialog = ProgressDialog(this)
                progressDialog.setMessage("Actualizando perfil...")
                progressDialog.setCancelable(false)
                progressDialog.show()

                // Actualizar en Firebase
                updateUserProfileInFirebase(newName, newCondition, progressDialog)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun updateUserProfileInFirebase(newName: String, newCondition: String, progressDialog: ProgressDialog) {
        val currentUser = auth.currentUser

        if (currentUser == null) {
            progressDialog.dismiss()
            Toast.makeText(this, "No hay usuario autenticado", Toast.LENGTH_SHORT).show()
            return
        }

        // 1. Actualizar el displayName en Firebase Auth
        val profileUpdates = UserProfileChangeRequest.Builder()
            .setDisplayName(newName)
            .build()

        currentUser.updateProfile(profileUpdates)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    // 2. Actualizar datos adicionales en Firestore
                    val userId = currentUser.uid
                    val userMap = hashMapOf(
                        "name" to newName,
                        "condition" to newCondition,
                        "email" to currentUser.email,
                        "updatedAt" to com.google.firebase.Timestamp.now()
                    )

                    db.collection("users").document(userId)
                        .set(userMap)
                        .addOnSuccessListener {
                            // 3. Actualizar SharedPreferences locales
                            val preferences = getSharedPreferences("MediControlPrefs", MODE_PRIVATE)
                            val editor = preferences.edit()
                            editor.putString("userName", newName)
                            editor.putString("userCondition", newCondition)
                            editor.apply()

                            // 4. Actualizar UI
                            tvUserName.text = newName
                            tvUserCondition.text = "Condición: $newCondition"

                            progressDialog.dismiss()
                            Toast.makeText(this, "Perfil actualizado correctamente", Toast.LENGTH_SHORT).show()
                        }
                        .addOnFailureListener { e ->
                            progressDialog.dismiss()
                            Toast.makeText(this, "Error al actualizar Firestore: ${e.message}", Toast.LENGTH_SHORT).show()
                        }
                } else {
                    progressDialog.dismiss()
                    Toast.makeText(this, "Error al actualizar perfil: ${task.exception?.message}", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun saveSwitchState(key: String, value: Boolean) {
        val preferences = getSharedPreferences("MediControlPrefs", MODE_PRIVATE)
        val editor = preferences.edit()
        editor.putBoolean(key, value)
        editor.apply()
    }

    private fun saveSpinnerSelection(key: String, value: Int) {
        val preferences = getSharedPreferences("MediControlPrefs", MODE_PRIVATE)
        val editor = preferences.edit()
        editor.putInt(key, value)
        editor.apply()
    }

    private fun showClearDataConfirmationDialog() {
        AlertDialog.Builder(this)
            .setTitle("Borrar todos los datos")
            .setMessage("¿Estás seguro de que deseas borrar todos tus datos? Esta acción no se puede deshacer.")
            .setPositiveButton("Borrar") { _, _ ->
                try {
                    // Borrar la base de datos SQLite
                    val db = dbHelper.writableDatabase
                    db.execSQL("DELETE FROM ${MediControlDbHelper.TABLE_MEDICATION_DOSES}")
                    db.execSQL("DELETE FROM ${MediControlDbHelper.TABLE_MEDICATIONS}")
                    db.execSQL("DELETE FROM ${MeasurementDataSource.TABLE_MEASUREMENTS}")

                    // Borrar SharedPreferences (excepto datos de usuario)
                    val preferences = getSharedPreferences("MediControlPrefs", MODE_PRIVATE)
                    val editor = preferences.edit()

                    // Guardar temporalmente datos de usuario
                    val userName = preferences.getString("userName", "Usuario")
                    val userCondition = preferences.getString("userCondition", "No especificada")

                    // Borrar todo
                    editor.clear()

                    // Restaurar datos de usuario
                    editor.putString("userName", userName)
                    editor.putString("userCondition", userCondition)

                    editor.apply()

                    // Recargar configuraciones
                    loadSwitchStates()
                    setupSpinners()

                    Toast.makeText(this, "Todos los datos han sido borrados", Toast.LENGTH_LONG).show()
                } catch (e: Exception) {
                    Toast.makeText(this, "Error al borrar datos: ${e.message}", Toast.LENGTH_LONG).show()
                    e.printStackTrace()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun showLogoutConfirmationDialog() {
        AlertDialog.Builder(this)
            .setTitle("Cerrar sesión")
            .setMessage("¿Estás seguro de que deseas cerrar sesión?")
            .setPositiveButton("Cerrar sesión") { _, _ ->
                // Cerrar sesión en Firebase
                auth.signOut()

                // Ir a la pantalla de bienvenida
                val intent = Intent(this, WelcomeActivity::class.java)
                intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                startActivity(intent)
                finish()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressed()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}