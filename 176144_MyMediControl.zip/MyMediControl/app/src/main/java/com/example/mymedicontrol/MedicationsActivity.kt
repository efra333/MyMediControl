package com.example.mymedicontrol

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

import com.google.android.material.floatingactionbutton.FloatingActionButton
import java.util.ArrayList

class MedicationsActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar
    private lateinit var rvMedications: RecyclerView
    private lateinit var tvEmptyMedications: TextView
    private lateinit var fabAddMedication: FloatingActionButton

    private lateinit var medicationAdapter: MedicationAdapter
    private val medicationsList = ArrayList<Medication>()

    // DataSource para interactuar con la base de datos
    private lateinit var medicationDataSource: MedicationDataSource

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_medications)

        // Inicializar la fuente de datos
        medicationDataSource = MedicationDataSource(this)

        // Inicializar vistas
        toolbar = findViewById(R.id.toolbar)
        rvMedications = findViewById(R.id.rvMedications)
        tvEmptyMedications = findViewById(R.id.tvEmptyMedications)
        fabAddMedication = findViewById(R.id.fabAddMedication)

        // Configurar toolbar
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Configurar RecyclerView
        setupRecyclerView()

        // Cargar medicamentos
        loadMedications()

        // Click listeners
        fabAddMedication.setOnClickListener {
            startActivity(Intent(this, AddMedicationActivity::class.java))
        }
    }

    private fun setupRecyclerView() {
        medicationAdapter = MedicationAdapter(medicationsList, onItemClickListener = { medication ->
            // Navegar a la pantalla de edición cuando se hace clic en un medicamento
            val intent = Intent(this, AddMedicationActivity::class.java)
            intent.putExtra("MEDICATION_ID", medication.id)
            startActivity(intent)
        }, onToggleActiveListener = { medication, isActive ->
            // Actualizar el estado activo/inactivo del medicamento
            updateMedicationActiveState(medication.id, isActive)
        })

        rvMedications.layoutManager = LinearLayoutManager(this)
        rvMedications.adapter = medicationAdapter
    }

    private fun loadMedications() {
        // Obtener medicamentos de la base de datos SQLite
        val medications = medicationDataSource.getActiveMedications()

        // Actualizar la lista
        medicationsList.clear()
        medicationsList.addAll(medications)

        medicationAdapter.notifyDataSetChanged()

        // Actualizar visibilidad según si hay medicamentos o no
        if (medicationsList.isEmpty()) {
            tvEmptyMedications.visibility = View.VISIBLE
            rvMedications.visibility = View.GONE
        } else {
            tvEmptyMedications.visibility = View.GONE
            rvMedications.visibility = View.VISIBLE
        }
    }

    private fun updateMedicationActiveState(id: Long, active: Boolean) {
        if (active) {
            // Si se está activando, simplemente actualizar el estado
            val medication = medicationDataSource.getMedicationById(id)
            medication?.let {
                it.active = true
                medicationDataSource.updateMedication(it)
            }
        } else {
            // Si se está desactivando, usar el método de desactivación
            medicationDataSource.deactivateMedication(id)
        }
    }

    override fun onResume() {
        super.onResume()
        // Recargar datos para reflejar cambios
        loadMedications()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressed()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}