package com.example.mymedicontrol



import java.util.Date

data class Measurement(
    val id: Long = 0,
    val type: String, // "GLUCOSE", "BLOOD_PRESSURE", "WEIGHT", etc.
    val value: String,
    val notes: String?,
    val datetime: Date,
    val createdAt: Date = Date()
)