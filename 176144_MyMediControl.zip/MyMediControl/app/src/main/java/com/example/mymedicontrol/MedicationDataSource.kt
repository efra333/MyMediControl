package com.example.mymedicontrol

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.util.Log
import java.util.Calendar

import java.util.Date

class MedicationDataSource(private val context: Context) {
    private val dbHelper = MediControlDbHelper(context)

    // Insertar un nuevo medicamento
    fun insertMedication(medication: Medication): Long {
        val db = dbHelper.writableDatabase

        val values = ContentValues().apply {
            put(MediControlDbHelper.COLUMN_NAME, medication.name)
            put(MediControlDbHelper.COLUMN_DOSE, medication.dose)
            put(MediControlDbHelper.COLUMN_SCHEDULE, medication.schedule)
            put(MediControlDbHelper.COLUMN_TYPE, medication.type.toString())
            put(MediControlDbHelper.COLUMN_ACTIVE, if (medication.active) 1 else 0)
            put(MediControlDbHelper.COLUMN_NEXT_DOSE, medication.nextDose?.time)
            put(MediControlDbHelper.COLUMN_CREATED_AT, medication.createdAt.time)
            put(MediControlDbHelper.COLUMN_UPDATED_AT, medication.updatedAt.time)
        }

        return db.insert(MediControlDbHelper.TABLE_MEDICATIONS, null, values)
    }

    // Obtener un medicamento por ID
    fun getMedicationById(id: Long): Medication? {
        val db = dbHelper.readableDatabase

        val projection = arrayOf(
            MediControlDbHelper.COLUMN_ID,
            MediControlDbHelper.COLUMN_NAME,
            MediControlDbHelper.COLUMN_DOSE,
            MediControlDbHelper.COLUMN_SCHEDULE,
            MediControlDbHelper.COLUMN_TYPE,
            MediControlDbHelper.COLUMN_ACTIVE,
            MediControlDbHelper.COLUMN_NEXT_DOSE,
            MediControlDbHelper.COLUMN_CREATED_AT,
            MediControlDbHelper.COLUMN_UPDATED_AT
        )

        val selection = "${MediControlDbHelper.COLUMN_ID} = ?"
        val selectionArgs = arrayOf(id.toString())

        val cursor = db.query(
            MediControlDbHelper.TABLE_MEDICATIONS,
            projection,
            selection,
            selectionArgs,
            null,
            null,
            null
        )

        var medication: Medication? = null

        with(cursor) {
            if (moveToFirst()) {
                medication = cursorToMedication(this)
            }
        }

        cursor.close()
        return medication
    }

    // Obtener todos los medicamentos activos
    fun getActiveMedications(): List<Medication> {
        val db = dbHelper.readableDatabase

        val projection = arrayOf(
            MediControlDbHelper.COLUMN_ID,
            MediControlDbHelper.COLUMN_NAME,
            MediControlDbHelper.COLUMN_DOSE,
            MediControlDbHelper.COLUMN_SCHEDULE,
            MediControlDbHelper.COLUMN_TYPE,
            MediControlDbHelper.COLUMN_ACTIVE,
            MediControlDbHelper.COLUMN_NEXT_DOSE,
            MediControlDbHelper.COLUMN_CREATED_AT,
            MediControlDbHelper.COLUMN_UPDATED_AT
        )

        val selection = "${MediControlDbHelper.COLUMN_ACTIVE} = ?"
        val selectionArgs = arrayOf("1")

        val cursor = db.query(
            MediControlDbHelper.TABLE_MEDICATIONS,
            projection,
            selection,
            selectionArgs,
            null,
            null,
            "${MediControlDbHelper.COLUMN_NAME} ASC"
        )

        val medications = mutableListOf<Medication>()

        with(cursor) {
            while (moveToNext()) {
                medications.add(cursorToMedication(this))
            }
        }

        cursor.close()
        return medications
    }

    // Obtener el próximo medicamento a tomar
    fun getNextMedication(): Medication? {
        val db = dbHelper.readableDatabase

        val projection = arrayOf(
            MediControlDbHelper.COLUMN_ID,
            MediControlDbHelper.COLUMN_NAME,
            MediControlDbHelper.COLUMN_DOSE,
            MediControlDbHelper.COLUMN_SCHEDULE,
            MediControlDbHelper.COLUMN_TYPE,
            MediControlDbHelper.COLUMN_ACTIVE,
            MediControlDbHelper.COLUMN_NEXT_DOSE,
            MediControlDbHelper.COLUMN_CREATED_AT,
            MediControlDbHelper.COLUMN_UPDATED_AT
        )

        val selection = "${MediControlDbHelper.COLUMN_ACTIVE} = ? AND ${MediControlDbHelper.COLUMN_NEXT_DOSE} IS NOT NULL"
        val selectionArgs = arrayOf("1")

        val cursor = db.query(
            MediControlDbHelper.TABLE_MEDICATIONS,
            projection,
            selection,
            selectionArgs,
            null,
            null,
            "${MediControlDbHelper.COLUMN_NEXT_DOSE} ASC",
            "1"
        )

        var medication: Medication? = null

        with(cursor) {
            if (moveToFirst()) {
                medication = cursorToMedication(this)
            }
        }

        cursor.close()
        return medication
    }

    // Actualizar un medicamento
    fun updateMedication(medication: Medication): Int {
        val db = dbHelper.writableDatabase

        val values = ContentValues().apply {
            put(MediControlDbHelper.COLUMN_NAME, medication.name)
            put(MediControlDbHelper.COLUMN_DOSE, medication.dose)
            put(MediControlDbHelper.COLUMN_SCHEDULE, medication.schedule)
            put(MediControlDbHelper.COLUMN_TYPE, medication.type.toString())
            put(MediControlDbHelper.COLUMN_ACTIVE, if (medication.active) 1 else 0)
            put(MediControlDbHelper.COLUMN_NEXT_DOSE, medication.nextDose?.time)
            put(MediControlDbHelper.COLUMN_UPDATED_AT, Date().time)
        }

        val selection = "${MediControlDbHelper.COLUMN_ID} = ?"
        val selectionArgs = arrayOf(medication.id.toString())

        return db.update(
            MediControlDbHelper.TABLE_MEDICATIONS,
            values,
            selection,
            selectionArgs
        )
    }

    // Actualizar la próxima dosis de un medicamento
    fun updateNextDose(medicationId: Long, nextDose: Date?): Int {
        val db = dbHelper.writableDatabase

        val values = ContentValues().apply {
            put(MediControlDbHelper.COLUMN_NEXT_DOSE, nextDose?.time)
            put(MediControlDbHelper.COLUMN_UPDATED_AT, Date().time)
        }

        val selection = "${MediControlDbHelper.COLUMN_ID} = ?"
        val selectionArgs = arrayOf(medicationId.toString())

        return db.update(
            MediControlDbHelper.TABLE_MEDICATIONS,
            values,
            selection,
            selectionArgs
        )
    }

    // Desactivar un medicamento
    fun deactivateMedication(id: Long): Int {
        val db = dbHelper.writableDatabase

        val values = ContentValues().apply {
            put(MediControlDbHelper.COLUMN_ACTIVE, 0)
            put(MediControlDbHelper.COLUMN_UPDATED_AT, Date().time)
        }

        val selection = "${MediControlDbHelper.COLUMN_ID} = ?"
        val selectionArgs = arrayOf(id.toString())

        return db.update(
            MediControlDbHelper.TABLE_MEDICATIONS,
            values,
            selection,
            selectionArgs
        )
    }

    // Registrar dosis tomada
    fun recordMedicationDose(medicationId: Long, doseDate: Date, status: String): Long {
        val db = dbHelper.writableDatabase

        // Primero verifica si ya existe una dosis programada para esta fecha/medicamento
        val existingDose = getExistingDose(medicationId, doseDate)

        if (existingDose != null) {
            // Si ya existe una entrada, actualízala en lugar de crear una nueva
            Log.d("MedicationDataSource", "Actualizando dosis existente ID: ${existingDose.id}")

            val values = ContentValues().apply {
                put(MediControlDbHelper.COLUMN_STATUS, status)
                put(MediControlDbHelper.COLUMN_TAKEN_AT, Date().time) // Actualiza con la hora real de toma
            }

            val selection = "${MediControlDbHelper.COLUMN_ID} = ?"
            val selectionArgs = arrayOf(existingDose.id.toString())

            db.update(MediControlDbHelper.TABLE_MEDICATION_DOSES, values, selection, selectionArgs)

            return existingDose.id // Devolver el ID de la dosis actualizada
        } else {
            // Si no existe, crear una nueva entrada
            Log.d("MedicationDataSource", "Creando nueva dosis para medicamento ID: $medicationId")

            val values = ContentValues().apply {
                put(MediControlDbHelper.COLUMN_MEDICATION_ID, medicationId)
                put(MediControlDbHelper.COLUMN_TAKEN_AT, Date().time) // Hora actual
                put(MediControlDbHelper.COLUMN_SCHEDULED, doseDate.time) // Hora programada original
                put(MediControlDbHelper.COLUMN_STATUS, status)
            }

            return db.insert(MediControlDbHelper.TABLE_MEDICATION_DOSES, null, values)
        }
    }

    // Método auxiliar para buscar dosis existentes
    private fun getExistingDose(medicationId: Long, doseDate: Date): MedicationDose? {
        val db = dbHelper.readableDatabase

        val projection = arrayOf(
            MediControlDbHelper.COLUMN_ID,
            MediControlDbHelper.COLUMN_MEDICATION_ID,
            MediControlDbHelper.COLUMN_TAKEN_AT,
            MediControlDbHelper.COLUMN_SCHEDULED,
            MediControlDbHelper.COLUMN_STATUS,
            MediControlDbHelper.COLUMN_NOTES
        )

        // Crear rango de tiempo para buscar (±5 minutos de la dosis programada)
        val calendar = Calendar.getInstance()
        calendar.time = doseDate

        // Restar 5 minutos
        calendar.add(Calendar.MINUTE, -5)
        val timeStart = calendar.timeInMillis

        // Sumar 10 minutos (5 minutos recupera el original, y 5 minutos más)
        calendar.add(Calendar.MINUTE, 10)
        val timeEnd = calendar.timeInMillis

        // Buscar dosis en ese rango de tiempo para este medicamento
        val selection = "${MediControlDbHelper.COLUMN_MEDICATION_ID} = ? AND ${MediControlDbHelper.COLUMN_SCHEDULED} BETWEEN ? AND ?"
        val selectionArgs = arrayOf(medicationId.toString(), timeStart.toString(), timeEnd.toString())

        val cursor = db.query(
            MediControlDbHelper.TABLE_MEDICATION_DOSES,
            projection,
            selection,
            selectionArgs,
            null,
            null,
            "${MediControlDbHelper.COLUMN_SCHEDULED} ASC",
            "1"
        )

        var dose: MedicationDose? = null

        if (cursor.moveToFirst()) {
            dose = cursorToDose(cursor)
        }

        cursor.close()
        return dose
    }

    // Obtener dosis de un medicamento
    fun getMedicationDoses(medicationId: Long): List<MedicationDose> {
        val db = dbHelper.readableDatabase

        val projection = arrayOf(
            MediControlDbHelper.COLUMN_ID,
            MediControlDbHelper.COLUMN_MEDICATION_ID,
            MediControlDbHelper.COLUMN_TAKEN_AT,
            MediControlDbHelper.COLUMN_SCHEDULED,
            MediControlDbHelper.COLUMN_STATUS,
            MediControlDbHelper.COLUMN_NOTES
        )

        val selection = "${MediControlDbHelper.COLUMN_MEDICATION_ID} = ?"
        val selectionArgs = arrayOf(medicationId.toString())

        val cursor = db.query(
            MediControlDbHelper.TABLE_MEDICATION_DOSES,
            projection,
            selection,
            selectionArgs,
            null,
            null,
            "${MediControlDbHelper.COLUMN_TAKEN_AT} DESC"
        )

        val doses = mutableListOf<MedicationDose>()

        with(cursor) {
            while (moveToNext()) {
                doses.add(cursorToDose(this))
            }
        }

        cursor.close()
        return doses
    }

    // Obtener todas las dosis
    fun getMedicationDoses(): List<MedicationDose> {
        val db = dbHelper.readableDatabase

        val projection = arrayOf(
            MediControlDbHelper.COLUMN_ID,
            MediControlDbHelper.COLUMN_MEDICATION_ID,
            MediControlDbHelper.COLUMN_TAKEN_AT,
            MediControlDbHelper.COLUMN_SCHEDULED,
            MediControlDbHelper.COLUMN_STATUS,
            MediControlDbHelper.COLUMN_NOTES
        )

        val cursor = db.query(
            MediControlDbHelper.TABLE_MEDICATION_DOSES,
            projection,
            null,
            null,
            null,
            null,
            "${MediControlDbHelper.COLUMN_TAKEN_AT} DESC"
        )

        val doses = mutableListOf<MedicationDose>()

        with(cursor) {
            while (moveToNext()) {
                doses.add(cursorToDose(this))
            }
        }

        cursor.close()
        return doses
    }


    // Método opcional para limpiar datos (usar con precaución)
    private fun deleteAllMedicationData() {
        val db = dbHelper.writableDatabase
        db.delete(MediControlDbHelper.TABLE_MEDICATION_DOSES, null, null)
        db.delete(MediControlDbHelper.TABLE_MEDICATIONS, null, null)
    }

    // Convertir un cursor a un objeto Medication
    private fun cursorToMedication(cursor: Cursor): Medication {
        val idIndex = cursor.getColumnIndexOrThrow(MediControlDbHelper.COLUMN_ID)
        val nameIndex = cursor.getColumnIndexOrThrow(MediControlDbHelper.COLUMN_NAME)
        val doseIndex = cursor.getColumnIndexOrThrow(MediControlDbHelper.COLUMN_DOSE)
        val scheduleIndex = cursor.getColumnIndexOrThrow(MediControlDbHelper.COLUMN_SCHEDULE)
        val typeIndex = cursor.getColumnIndexOrThrow(MediControlDbHelper.COLUMN_TYPE)
        val activeIndex = cursor.getColumnIndexOrThrow(MediControlDbHelper.COLUMN_ACTIVE)
        val nextDoseIndex = cursor.getColumnIndexOrThrow(MediControlDbHelper.COLUMN_NEXT_DOSE)
        val createdAtIndex = cursor.getColumnIndexOrThrow(MediControlDbHelper.COLUMN_CREATED_AT)
        val updatedAtIndex = cursor.getColumnIndexOrThrow(MediControlDbHelper.COLUMN_UPDATED_AT)

        return Medication(
            id = cursor.getLong(idIndex),
            name = cursor.getString(nameIndex),
            dose = cursor.getString(doseIndex),
            schedule = cursor.getString(scheduleIndex),
            type = MedicationType.fromString(cursor.getString(typeIndex)),
            active = cursor.getInt(activeIndex) == 1,
            nextDose = if (cursor.isNull(nextDoseIndex)) null else Date(cursor.getLong(nextDoseIndex)),
            createdAt = Date(cursor.getLong(createdAtIndex)),
            updatedAt = Date(cursor.getLong(updatedAtIndex))
        )
    }


    // Convertir un cursor a un objeto MedicationDose
    private fun cursorToDose(cursor: Cursor): MedicationDose {
        val idIndex = cursor.getColumnIndexOrThrow(MediControlDbHelper.COLUMN_ID)
        val medicationIdIndex = cursor.getColumnIndexOrThrow(MediControlDbHelper.COLUMN_MEDICATION_ID)
        val takenAtIndex = cursor.getColumnIndexOrThrow(MediControlDbHelper.COLUMN_TAKEN_AT)
        val scheduledIndex = cursor.getColumnIndexOrThrow(MediControlDbHelper.COLUMN_SCHEDULED)
        val statusIndex = cursor.getColumnIndexOrThrow(MediControlDbHelper.COLUMN_STATUS)
        val notesIndex = cursor.getColumnIndexOrThrow(MediControlDbHelper.COLUMN_NOTES)

        return MedicationDose(
            id = cursor.getLong(idIndex),
            medicationId = cursor.getLong(medicationIdIndex),
            takenAt = Date(cursor.getLong(takenAtIndex)),
            scheduled = Date(cursor.getLong(scheduledIndex)),
            status = cursor.getString(statusIndex),
            notes = if (cursor.isNull(notesIndex)) null else cursor.getString(notesIndex)
        )
    }
}