package com.example.mymedicontrol

import android.app.AlertDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.FirebaseApp
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class AddMedicationActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar
    private lateinit var etMedicationName: TextInputEditText
    private lateinit var etMedicationDose: TextInputEditText
    private lateinit var spinnerMedicationType: Spinner
    private lateinit var tvSelectTime: TextView
    private lateinit var btnAddTime: Button
    private lateinit var rvTimes: RecyclerView
    private lateinit var rgFrequency: RadioGroup
    private lateinit var rbDaily: RadioButton
    private lateinit var rbSpecificDays: RadioButton
    private lateinit var llDays: LinearLayout
    private lateinit var btnSaveMedication: Button
    private lateinit var btnDeleteMedication: Button

    // Checkboxes para días de la semana
    private lateinit var cbMonday: CheckBox
    private lateinit var cbTuesday: CheckBox
    private lateinit var cbWednesday: CheckBox
    private lateinit var cbThursday: CheckBox
    private lateinit var cbFriday: CheckBox
    private lateinit var cbSaturday: CheckBox
    private lateinit var cbSunday: CheckBox

    // Fuente de datos
    private lateinit var medicationDataSource: MedicationDataSource

    private var medicationId: Long = -1
    private val selectedTimes = ArrayList<String>()
    private lateinit var timesAdapter: TimesAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inicializar Firebase
        FirebaseApp.initializeApp(this)

        setContentView(R.layout.activity_add_medication)

        // Inicializar la fuente de datos
        medicationDataSource = MedicationDataSource(this)

        // Inicializar vistas
        toolbar = findViewById(R.id.toolbar)
        etMedicationName = findViewById(R.id.etMedicationName)
        etMedicationDose = findViewById(R.id.etMedicationDose)
        spinnerMedicationType = findViewById(R.id.spinnerMedicationType)
        tvSelectTime = findViewById(R.id.tvSelectTime)
        btnAddTime = findViewById(R.id.btnAddTime)
        rvTimes = findViewById(R.id.rvTimes)
        rgFrequency = findViewById(R.id.rgFrequency)
        rbDaily = findViewById(R.id.rbDaily)
        rbSpecificDays = findViewById(R.id.rbSpecificDays)
        llDays = findViewById(R.id.llDays)
        btnSaveMedication = findViewById(R.id.btnSaveMedication)
        btnDeleteMedication = findViewById(R.id.btnDeleteMedication)

        // Inicializar checkboxes
        cbMonday = findViewById(R.id.cbMonday)
        cbTuesday = findViewById(R.id.cbTuesday)
        cbWednesday = findViewById(R.id.cbWednesday)
        cbThursday = findViewById(R.id.cbThursday)
        cbFriday = findViewById(R.id.cbFriday)
        cbSaturday = findViewById(R.id.cbSaturday)
        cbSunday = findViewById(R.id.cbSunday)

        // Configurar toolbar
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Configurar spinner de tipos de medicamento
        setupMedicationTypeSpinner()

        // Configurar RecyclerView de horarios
        setupTimesRecyclerView()

        // Verificar si estamos editando un medicamento existente
        medicationId = intent.getLongExtra("MEDICATION_ID", -1)
        if (medicationId != -1L) {
            toolbar.title = "Editar Medicamento"
            loadMedicationData()
            btnDeleteMedication.visibility = View.VISIBLE
        }

        // Click listeners
        setupClickListeners()
    }

    private fun setupMedicationTypeSpinner() {
        // Valores internos del enum
        val medicationTypes = arrayOf("PILL", "CAPSULE", "LIQUID", "INJECTION", "OTHER")
        // Nombres mostrados en español para mejor UX
        val displayNames = arrayOf("Píldora", "Cápsula", "Líquido", "Inyección", "Otro")

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, displayNames)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerMedicationType.adapter = adapter
    }

    private fun setupTimesRecyclerView() {
        timesAdapter = TimesAdapter(selectedTimes) { position ->
            // Eliminar horario al hacer clic
            selectedTimes.removeAt(position)
            timesAdapter.notifyItemRemoved(position)
            updateTimesVisibility()
        }
        rvTimes.layoutManager = LinearLayoutManager(this)
        rvTimes.adapter = timesAdapter
    }

    private fun setupClickListeners() {
        // Seleccionar hora
        tvSelectTime.setOnClickListener {
            showTimePickerDialog()
        }

        // Agregar horario
        btnAddTime.setOnClickListener {
            if (tvSelectTime.text != "Seleccionar hora") {
                val timeStr = tvSelectTime.text.toString()
                if (!selectedTimes.contains(timeStr)) {
                    selectedTimes.add(timeStr)
                    selectedTimes.sort()
                    timesAdapter.notifyDataSetChanged()
                    updateTimesVisibility()
                    tvSelectTime.text = "Seleccionar hora"
                } else {
                    Toast.makeText(this, "Este horario ya está agregado", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Selecciona una hora primero", Toast.LENGTH_SHORT).show()
            }
        }

        // Cambio en el radio group de frecuencia
        rgFrequency.setOnCheckedChangeListener { _, checkedId ->
            llDays.visibility = if (checkedId == R.id.rbSpecificDays) View.VISIBLE else View.GONE
        }

        // Guardar medicamento
        btnSaveMedication.setOnClickListener {
            saveMedication()
        }

        // Eliminar medicamento
        btnDeleteMedication.setOnClickListener {
            showDeleteConfirmationDialog()
        }
    }

    private fun showTimePickerDialog() {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR_OF_DAY)
        val minute = calendar.get(Calendar.MINUTE)

        val timePickerDialog = TimePickerDialog(
            this,
            { _, selectedHour, selectedMinute ->
                val time = String.format("%02d:%02d", selectedHour, selectedMinute)
                tvSelectTime.text = time
            },
            hour,
            minute,
            true
        )

        timePickerDialog.show()
    }

    private fun updateTimesVisibility() {
        if (selectedTimes.isEmpty()) {
            rvTimes.visibility = View.GONE
        } else {
            rvTimes.visibility = View.VISIBLE
        }
    }

    private fun loadMedicationData() {
        // Cargar datos del medicamento desde la base de datos
        val medication = medicationDataSource.getMedicationById(medicationId)

        if (medication != null) {
            etMedicationName.setText(medication.name)
            etMedicationDose.setText(medication.dose)

            // Seleccionar tipo de medicamento
            val typePosition = when (medication.type) {
                MedicationType.PILL -> 0
                MedicationType.CAPSULE -> 1
                MedicationType.LIQUID -> 2
                MedicationType.INJECTION -> 3
                else -> 4
            }
            spinnerMedicationType.setSelection(typePosition)

            // Cargar horarios
            val schedule = medication.schedule
            if (schedule.contains("|")) {
                // Horario para días específicos
                val parts = schedule.split("|")
                val times = parts[0].split(", ")
                val days = parts[1]

                // Cargar horarios
                selectedTimes.clear()
                selectedTimes.addAll(times)
                timesAdapter.notifyDataSetChanged()
                updateTimesVisibility()

                // Configurar frecuencia
                rbSpecificDays.isChecked = true
                llDays.visibility = View.VISIBLE

                // Marcar días
                cbMonday.isChecked = days.contains("L")
                cbTuesday.isChecked = days.contains("M")
                cbWednesday.isChecked = days.contains("X")
                cbThursday.isChecked = days.contains("J")
                cbFriday.isChecked = days.contains("V")
                cbSaturday.isChecked = days.contains("S")
                cbSunday.isChecked = days.contains("D")
            } else {
                // Horario diario
                selectedTimes.clear()
                selectedTimes.addAll(schedule.split(", "))
                timesAdapter.notifyDataSetChanged()
                updateTimesVisibility()

                // Configurar frecuencia
                rbDaily.isChecked = true
                llDays.visibility = View.GONE
            }
        }
    }

    private fun saveMedication() {
        val name = etMedicationName.text.toString().trim()
        val dose = etMedicationDose.text.toString().trim()
        val typePosition = spinnerMedicationType.selectedItemPosition

        // Validaciones básicas
        if (name.isEmpty()) {
            etMedicationName.error = "Ingresa el nombre del medicamento"
            etMedicationName.requestFocus()
            return
        }

        if (dose.isEmpty()) {
            etMedicationDose.error = "Ingresa la dosis"
            etMedicationDose.requestFocus()
            return
        }

        if (selectedTimes.isEmpty()) {
            Toast.makeText(this, "Agrega al menos un horario", Toast.LENGTH_SHORT).show()
            return
        }

        // Obtener tipo de medicamento
        val type = when (typePosition) {
            0 -> MedicationType.PILL
            1 -> MedicationType.CAPSULE
            2 -> MedicationType.LIQUID
            3 -> MedicationType.INJECTION
            else -> MedicationType.OTHER
        }

        // Crear string de horario/frecuencia
        val schedule = if (rbDaily.isChecked) {
            selectedTimes.joinToString(", ")
        } else {
            // Incluir días seleccionados
            val days = StringBuilder()
            if (cbMonday.isChecked) days.append("L")
            if (cbTuesday.isChecked) days.append("M")
            if (cbWednesday.isChecked) days.append("X")
            if (cbThursday.isChecked) days.append("J")
            if (cbFriday.isChecked) days.append("V")
            if (cbSaturday.isChecked) days.append("S")
            if (cbSunday.isChecked) days.append("D")

            "${selectedTimes.joinToString(", ")}|$days"
        }

        // Calcular próxima dosis
        val nextDose = calculateNextDose()

        // Crear objeto Medication
        val medication = Medication(
            id = if (medicationId == -1L) 0 else medicationId,
            name = name,
            dose = dose,
            schedule = schedule,
            type = type,
            active = true,
            nextDose = nextDose,
            createdAt = Date(),
            updatedAt = Date()
        )

        // Guardar en la base de datos
        val result = if (medicationId == -1L) {
            // Insertar nuevo medicamento
            try {
                // CAMBIO: Agregar log para depuración
                Log.d("AddMedication", "Guardando nuevo medicamento: ${medication.name}")
                val newId = medicationDataSource.insertMedication(medication)

                // CAMBIO: Registrar dosis inicial si es un medicamento nuevo
                if (newId > 0) {
                    try {
                        // CAMBIO: Registrar la primera dosis como "TAKEN" (tomada)
                        // para que aparezca en el historial
                        val doseId = medicationDataSource.recordMedicationDose(
                            medicationId = newId,
                            doseDate = Date(), // Fecha actual para marcarla como tomada ahora
                            status = "TAKEN"  // Estado "TAKEN" para que aparezca como completada
                        )

                        Log.d("AddMedication", "Dosis inicial registrada: ID=$doseId para medicamento ID=$newId")

                        // CAMBIO: También registrar una dosis futura (programada)
                        val scheduledDoseId = medicationDataSource.recordMedicationDose(
                            medicationId = newId,
                            doseDate = nextDose, // Próxima dosis calculada
                            status = "SCHEDULED" // Estado "SCHEDULED" para marcarla como programada
                        )

                        Log.d("AddMedication", "Dosis programada registrada: ID=$scheduledDoseId para medicamento ID=$newId, Fecha=${nextDose}")
                    } catch (e: Exception) {
                        Log.e("AddMedication", "Error al registrar dosis inicial", e)
                        // No interrumpir el flujo por un error en la dosis
                    }
                }

                newId
            } catch (e: Exception) {
                Log.e("AddMedication", "Error al insertar medicamento", e)
                -1
            }
        } else {
            // Actualizar medicamento existente
            try {
                Log.d("AddMedication", "Actualizando medicamento existente: ID=${medication.id}")
                val updateResult = medicationDataSource.updateMedication(medication)
                if (updateResult > 0) medicationId else -1
            } catch (e: Exception) {
                Log.e("AddMedication", "Error al actualizar medicamento", e)
                -1
            }
        }

        if (result > 0) {
            // CAMBIO: Verificar que el medicamento se guardó correctamente
            val savedMedication = medicationDataSource.getMedicationById(result)
            if (savedMedication != null) {
                Log.d("AddMedication", "Medicamento guardado correctamente: ${savedMedication.name}")

                // Verificar dosis asociadas
                val doses = medicationDataSource.getMedicationDoses(result)
                Log.d("AddMedication", "Dosis asociadas: ${doses.size}")

                for (dose in doses) {
                    Log.d("AddMedication", "Dosis: ID=${dose.id}, Estado=${dose.status}, Fecha=${dose.takenAt}")
                }
            }

            Toast.makeText(this, "Medicamento guardado correctamente", Toast.LENGTH_SHORT).show()
            finish()
        } else {
            Toast.makeText(this, "Error al guardar el medicamento", Toast.LENGTH_SHORT).show()
        }
    }

    private fun calculateNextDose(): Date {
        // Cálculo simple de la próxima dosis
        val calendar = Calendar.getInstance()
        val now = calendar.time

        // Obtener la hora más cercana de la lista de horarios
        val timeFormatter = SimpleDateFormat("HH:mm", Locale.getDefault())
        val currentTimeStr = timeFormatter.format(now)

        var closestTime = selectedTimes.first()

        for (time in selectedTimes) {
            if (time > currentTimeStr) {
                closestTime = time
                break
            }
        }

        // Configurar la fecha y hora de la próxima dosis
        val parts = closestTime.split(":")
        val hour = parts[0].toInt()
        val minute = parts[1].toInt()

        calendar.set(Calendar.HOUR_OF_DAY, hour)
        calendar.set(Calendar.MINUTE, minute)
        calendar.set(Calendar.SECOND, 0)

        // Si la hora ya pasó, añadir un día
        if (calendar.time.before(now)) {
            calendar.add(Calendar.DAY_OF_MONTH, 1)
        }

        // Si tiene frecuencia de días específicos, buscar el próximo día válido
        if (rbSpecificDays.isChecked) {
            // Obtener los días seleccionados
            val selectedDays = ArrayList<Int>()
            if (cbMonday.isChecked) selectedDays.add(Calendar.MONDAY)
            if (cbTuesday.isChecked) selectedDays.add(Calendar.TUESDAY)
            if (cbWednesday.isChecked) selectedDays.add(Calendar.WEDNESDAY)
            if (cbThursday.isChecked) selectedDays.add(Calendar.THURSDAY)
            if (cbFriday.isChecked) selectedDays.add(Calendar.FRIDAY)
            if (cbSaturday.isChecked) selectedDays.add(Calendar.SATURDAY)
            if (cbSunday.isChecked) selectedDays.add(Calendar.SUNDAY)

            if (selectedDays.isNotEmpty()) {
                // Avanzar hasta encontrar un día válido
                var daysChecked = 0
                while (!selectedDays.contains(calendar.get(Calendar.DAY_OF_WEEK)) && daysChecked < 7) {
                    calendar.add(Calendar.DAY_OF_MONTH, 1)
                    daysChecked++
                }
            }
        }

        return calendar.time
    }

    private fun showDeleteConfirmationDialog() {
        AlertDialog.Builder(this)
            .setTitle("Eliminar medicamento")
            .setMessage("¿Estás seguro de que deseas eliminar este medicamento?")
            .setPositiveButton("Eliminar") { _, _ ->
                // Eliminar medicamento de la base de datos
                if (medicationId != -1L) {
                    val result = medicationDataSource.deactivateMedication(medicationId)

                    if (result > 0) {
                        Toast.makeText(this, "Medicamento eliminado", Toast.LENGTH_SHORT).show()
                        finish()
                    } else {
                        Toast.makeText(this, "Error al eliminar el medicamento", Toast.LENGTH_SHORT).show()
                    }
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressed()
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}