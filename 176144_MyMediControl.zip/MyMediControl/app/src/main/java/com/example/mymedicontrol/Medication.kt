package com.example.mymedicontrol
// app/src/main/java/com/example/mymedicontrol/model/Medication.kt


import java.util.Date

enum class MedicationType {
    PILL, CAPSULE, LIQUID, INJECTION, OTHER;

    companion object {
        fun fromString(type: String): MedicationType {
            return try {
                valueOf(type)
            } catch (e: Exception) {
                OTHER
            }
        }
    }
}

data class Medication(
    val id: Long = 0,
    val name: String,
    val dose: String,
    val schedule: String,
    val type: MedicationType,
    var active: Boolean = true,
    val nextDose: Date? = null,
    val createdAt: Date = Date(),
    val updatedAt: Date = Date()
)