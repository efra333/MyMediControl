package com.example.mymedicontrol

// app/src/main/java/com/example/mymedicontrol/data/MediControlDbHelper.kt

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class MediControlDbHelper(context: Context) : SQLiteOpenHelper(
    context, DATABASE_NAME, null, DATABASE_VERSION
) {
    // Store the context
    private val appContext = context.applicationContext

    companion object {
        // Versión de la base de datos
        const val DATABASE_VERSION = 1

        // Nombre de la base de datos
        const val DATABASE_NAME = "MediControl.db"

        // Tabla de Medicamentos
        const val TABLE_MEDICATIONS = "medications"

        // Columnas para la tabla de medicamentos
        const val COLUMN_ID = "id"
        const val COLUMN_NAME = "name"
        const val COLUMN_DOSE = "dose"
        const val COLUMN_SCHEDULE = "schedule"
        const val COLUMN_TYPE = "type"
        const val COLUMN_ACTIVE = "active"
        const val COLUMN_NEXT_DOSE = "next_dose"
        const val COLUMN_CREATED_AT = "created_at"
        const val COLUMN_UPDATED_AT = "updated_at"

        // Tabla de Dosis de Medicamentos
        const val TABLE_MEDICATION_DOSES = "medication_doses"

        // Columnas adicionales para la tabla de dosis
        const val COLUMN_MEDICATION_ID = "medication_id"
        const val COLUMN_TAKEN_AT = "taken_at"
        const val COLUMN_SCHEDULED = "scheduled"
        const val COLUMN_STATUS = "status"
        const val COLUMN_NOTES = "notes"
    }

    // Script SQL para crear la tabla de medicamentos
    private val SQL_CREATE_MEDICATIONS = """
        CREATE TABLE $TABLE_MEDICATIONS (
            $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            $COLUMN_NAME TEXT NOT NULL,
            $COLUMN_DOSE TEXT NOT NULL,
            $COLUMN_SCHEDULE TEXT NOT NULL,
            $COLUMN_TYPE TEXT NOT NULL,
            $COLUMN_ACTIVE INTEGER NOT NULL DEFAULT 1,
            $COLUMN_NEXT_DOSE INTEGER,
            $COLUMN_CREATED_AT INTEGER NOT NULL,
            $COLUMN_UPDATED_AT INTEGER NOT NULL
        );
    """.trimIndent()

    // Script SQL para crear la tabla de dosis
    private val SQL_CREATE_MEDICATION_DOSES = """
        CREATE TABLE $TABLE_MEDICATION_DOSES (
            $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
            $COLUMN_MEDICATION_ID INTEGER NOT NULL,
            $COLUMN_TAKEN_AT INTEGER NOT NULL,
            $COLUMN_SCHEDULED INTEGER NOT NULL,
            $COLUMN_STATUS TEXT NOT NULL,
            $COLUMN_NOTES TEXT,
            FOREIGN KEY ($COLUMN_MEDICATION_ID) REFERENCES $TABLE_MEDICATIONS ($COLUMN_ID)
        );
    """.trimIndent()

    override fun onCreate(db: SQLiteDatabase) {
        // Crear las tablas
        db.execSQL(SQL_CREATE_MEDICATIONS)
        db.execSQL(SQL_CREATE_MEDICATION_DOSES)

        // Directly create the measurement table without using MeasurementDataSource
        val SQL_CREATE_MEASUREMENTS = """
            CREATE TABLE ${MeasurementDataSource.TABLE_MEASUREMENTS} (
                ${MeasurementDataSource.COLUMN_ID} INTEGER PRIMARY KEY AUTOINCREMENT,
                ${MeasurementDataSource.COLUMN_TYPE} TEXT NOT NULL,
                ${MeasurementDataSource.COLUMN_VALUE} TEXT NOT NULL,
                ${MeasurementDataSource.COLUMN_NOTES} TEXT,
                ${MeasurementDataSource.COLUMN_DATETIME} INTEGER NOT NULL,
                ${MeasurementDataSource.COLUMN_CREATED_AT} INTEGER NOT NULL
            );
        """.trimIndent()

        db.execSQL(SQL_CREATE_MEASUREMENTS)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // En caso de actualización, eliminar tablas viejas y crear nuevas
        db.execSQL("DROP TABLE IF EXISTS $TABLE_MEDICATION_DOSES")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_MEDICATIONS")
        db.execSQL("DROP TABLE IF EXISTS ${MeasurementDataSource.TABLE_MEASUREMENTS}")
        onCreate(db)
    }
}