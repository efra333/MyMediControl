package com.example.mymedicontrol

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.Switch
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class MedicationAdapter(
    private val medications: List<Medication>,
    private val onItemClickListener: (Medication) -> Unit,
    private val onToggleActiveListener: (Medication, Boolean) -> Unit
) : RecyclerView.Adapter<MedicationAdapter.MedicationViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MedicationViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_medication, parent, false)
        return MedicationViewHolder(view)
    }

    override fun onBindViewHolder(holder: MedicationViewHolder, position: Int) {
        val medication = medications[position]
        holder.bind(medication)
    }

    override fun getItemCount(): Int = medications.size

    inner class MedicationViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val ivMedicationType: ImageView = itemView.findViewById(R.id.ivMedicationType)
        private val tvMedicationName: TextView = itemView.findViewById(R.id.tvMedicationName)
        private val tvMedicationDose: TextView = itemView.findViewById(R.id.tvMedicationDose)
        private val tvMedicationSchedule: TextView = itemView.findViewById(R.id.tvMedicationSchedule)
        private val switchActive: Switch = itemView.findViewById(R.id.switchActive)

        fun bind(medication: Medication) {
            tvMedicationName.text = medication.name
            tvMedicationDose.text = medication.dose
            tvMedicationSchedule.text = medication.schedule
            switchActive.isChecked = medication.active

            // Configurar icono según el tipo
            val typeDrawable = when (medication.type) {
                MedicationType.PILL -> R.drawable.ic_pill
                MedicationType.CAPSULE -> R.drawable.ic_capsule
                MedicationType.LIQUID -> R.drawable.ic_liquid
                MedicationType.INJECTION -> R.drawable.ic_injection
                else -> R.drawable.ic_medication
            }
            ivMedicationType.setImageResource(typeDrawable)

            // Configurar click listener del item
            itemView.setOnClickListener {
                onItemClickListener(medication)
            }

            // Configurar listener del switch
            switchActive.setOnCheckedChangeListener { _, isChecked ->
                onToggleActiveListener(medication, isChecked)
            }
        }
    }
}