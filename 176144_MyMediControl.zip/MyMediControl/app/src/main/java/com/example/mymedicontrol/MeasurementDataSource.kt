package com.example.mymedicontrol

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteException
import android.util.Log
import java.util.Date

class MeasurementDataSource(context: Context) {
    private val TAG = "MeasurementDataSource"
    private val dbHelper: MediControlDbHelper = MediControlDbHelper(context) // ✅ No nullable

    companion object {
        const val TABLE_MEASUREMENTS = "measurements"
        const val COLUMN_ID = "id"
        const val COLUMN_TYPE = "type"
        const val COLUMN_VALUE = "value"
        const val COLUMN_NOTES = "notes"
        const val COLUMN_DATETIME = "datetime"
        const val COLUMN_CREATED_AT = "created_at"
    }

    fun createTable(db: android.database.sqlite.SQLiteDatabase) {
        val SQL_CREATE_MEASUREMENTS = """
            CREATE TABLE $TABLE_MEASUREMENTS (
                $COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COLUMN_TYPE TEXT NOT NULL,
                $COLUMN_VALUE TEXT NOT NULL,
                $COLUMN_NOTES TEXT,
                $COLUMN_DATETIME INTEGER NOT NULL,
                $COLUMN_CREATED_AT INTEGER NOT NULL
            );
        """.trimIndent()

        db.execSQL(SQL_CREATE_MEASUREMENTS)
    }

    fun insertMeasurement(measurement: Measurement): Long {
        val db = dbHelper.writableDatabase
        var id: Long = -1

        try {
            db.beginTransaction()

            val values = ContentValues().apply {
                put(COLUMN_TYPE, measurement.type)
                put(COLUMN_VALUE, measurement.value)
                if (measurement.notes != null) {
                    put(COLUMN_NOTES, measurement.notes)
                } else {
                    putNull(COLUMN_NOTES)
                }
                put(COLUMN_DATETIME, measurement.datetime.time)
                put(COLUMN_CREATED_AT, measurement.createdAt.time)
            }

            Log.d(TAG, "Insertando: Type=${measurement.type}, Value=${measurement.value}, DateTime=${measurement.datetime}, CreatedAt=${measurement.createdAt}")

            if (!isTableExists(db, TABLE_MEASUREMENTS)) {
                Log.w(TAG, "La tabla $TABLE_MEASUREMENTS no existe.")
                return -1
            }

            id = db.insert(TABLE_MEASUREMENTS, null, values)

            if (id != -1L) {
                db.setTransactionSuccessful()
                Log.d(TAG, "Insertado con ID: $id")
            } else {
                Log.e(TAG, "Error al insertar. ID devuelto: $id")
            }
        } catch (e: SQLiteException) {
            Log.e(TAG, "Error SQLite: ${e.message}", e)
        } catch (e: Exception) {
            Log.e(TAG, "Error inesperado: ${e.message}", e)
        } finally {
            if (db.inTransaction()) db.endTransaction()
        }

        return id
    }

    private fun isTableExists(db: android.database.sqlite.SQLiteDatabase, tableName: String): Boolean {
        var cursor: Cursor? = null
        return try {
            cursor = db.rawQuery(
                "SELECT name FROM sqlite_master WHERE type='table' AND name=?",
                arrayOf(tableName)
            )
            cursor.moveToFirst()
        } catch (e: Exception) {
            Log.e(TAG, "Error al verificar tabla: ${e.message}", e)
            false
        } finally {
            cursor?.close()
        }
    }

    fun getMeasurementById(id: Long): Measurement? {
        val db = dbHelper.readableDatabase
        var measurement: Measurement? = null
        var cursor: Cursor? = null

        try {
            val projection = arrayOf(COLUMN_ID, COLUMN_TYPE, COLUMN_VALUE, COLUMN_NOTES, COLUMN_DATETIME, COLUMN_CREATED_AT)
            val selection = "$COLUMN_ID = ?"
            val selectionArgs = arrayOf(id.toString())

            cursor = db.query(TABLE_MEASUREMENTS, projection, selection, selectionArgs, null, null, null)

            if (cursor.moveToFirst()) {
                measurement = cursorToMeasurement(cursor)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error al obtener medición por ID: ${e.message}", e)
        } finally {
            cursor?.close()
        }

        return measurement
    }

    fun getMeasurements(): List<Measurement> {
        val db = dbHelper.readableDatabase
        val measurements = mutableListOf<Measurement>()
        var cursor: Cursor? = null

        try {
            if (!isTableExists(db, TABLE_MEASUREMENTS)) {
                Log.w(TAG, "Tabla $TABLE_MEASUREMENTS no existe")
                return emptyList()
            }

            val projection = arrayOf(COLUMN_ID, COLUMN_TYPE, COLUMN_VALUE, COLUMN_NOTES, COLUMN_DATETIME, COLUMN_CREATED_AT)
            cursor = db.query(TABLE_MEASUREMENTS, projection, null, null, null, null, "$COLUMN_DATETIME DESC")

            while (cursor.moveToNext()) {
                try {
                    measurements.add(cursorToMeasurement(cursor))
                } catch (e: Exception) {
                    Log.e(TAG, "Error procesando fila: ${e.message}", e)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error al obtener mediciones: ${e.message}", e)
        } finally {
            cursor?.close()
        }

        return measurements
    }

    fun getMeasurementsByType(type: String): List<Measurement> {
        val db = dbHelper.readableDatabase
        val measurements = mutableListOf<Measurement>()
        var cursor: Cursor? = null

        try {
            val projection = arrayOf(COLUMN_ID, COLUMN_TYPE, COLUMN_VALUE, COLUMN_NOTES, COLUMN_DATETIME, COLUMN_CREATED_AT)
            val selection = "$COLUMN_TYPE = ?"
            val selectionArgs = arrayOf(type)

            cursor = db.query(TABLE_MEASUREMENTS, projection, selection, selectionArgs, null, null, "$COLUMN_DATETIME DESC")

            while (cursor.moveToNext()) {
                try {
                    measurements.add(cursorToMeasurement(cursor))
                } catch (e: Exception) {
                    Log.e(TAG, "Error procesando fila por tipo: ${e.message}", e)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error al obtener por tipo: ${e.message}", e)
        } finally {
            cursor?.close()
        }

        return measurements
    }

    fun deleteMeasurement(id: Long): Int {
        val db = dbHelper.writableDatabase
        var result = 0

        try {
            db.beginTransaction()

            val selection = "$COLUMN_ID = ?"
            val selectionArgs = arrayOf(id.toString())

            result = db.delete(TABLE_MEASUREMENTS, selection, selectionArgs)

            if (result > 0) {
                db.setTransactionSuccessful()
                Log.d(TAG, "Medición eliminada. ID: $id")
            } else {
                Log.w(TAG, "No se encontró la medición. ID: $id")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error al eliminar: ${e.message}", e)
        } finally {
            if (db.inTransaction()) db.endTransaction()
        }

        return result
    }

    private fun cursorToMeasurement(cursor: Cursor): Measurement {
        return try {
            Measurement(
                id = cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_ID)),
                type = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_TYPE)),
                value = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_VALUE)),
                notes = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_NOTES)),
                datetime = Date(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_DATETIME))),
                createdAt = Date(cursor.getLong(cursor.getColumnIndexOrThrow(COLUMN_CREATED_AT)))
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error al convertir cursor: ${e.message}", e)
            Measurement(-1, "ERROR", "Error: ${e.message}", null, Date(), Date())
        }
    }

    fun close() {
        try {
            dbHelper.close()
            Log.d(TAG, "Conexión cerrada correctamente")
        } catch (e: Exception) {
            Log.e(TAG, "Error al cerrar DB: ${e.message}", e)
        }
    }
}
