package com.example.mymedicontrol

import android.util.Log
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class NutritionService {
    companion object {
        private const val TAG = "NutritionService"
        private const val API_KEY = "hWF10o6IolkiR0TBXQINFg==wfnX2tBtEvcTJ8Ue" // Regístrate en CalorieNinjas para obtener tu API key
        private const val BASE_URL = "https://api.calorieninjas.com/v1/nutrition?query="
    }

    // Lista de alimentos recomendados según tipos de medicamentos
    private val healthyFoods = listOf(
        "banana", "spinach", "apple", "avocado", "salmon",
        "broccoli", "blueberries", "chicken breast", "oats", "almonds",
        "greek yogurt", "oranges", "sweet potato", "lentils", "kiwi",
        "eggs", "quinoa", "tomato", "kale", "walnuts"
    )

    // Obtener información nutricional de un alimento específico
    suspend fun getNutritionInfo(food: String): NutritionResponse {
        return withContext(Dispatchers.IO) {
            try {
                val encodedQuery = URLEncoder.encode(food, "UTF-8")
                val url = URL("$BASE_URL$encodedQuery")

                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.setRequestProperty("X-Api-Key", API_KEY)

                val responseCode = connection.responseCode
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    val response = StringBuilder()
                    BufferedReader(InputStreamReader(connection.inputStream)).use { reader ->
                        var line: String?
                        while (reader.readLine().also { line = it } != null) {
                            response.append(line)
                        }
                    }

                    // Parsear la respuesta JSON
                    val jsonObject = JSONObject(response.toString())
                    val itemsArray = jsonObject.getJSONArray("items")
                    val items = mutableListOf<NutritionItem>()

                    for (i in 0 until itemsArray.length()) {
                        val itemObject = itemsArray.getJSONObject(i)
                        items.add(
                            NutritionItem(
                                name = itemObject.getString("name"),
                                calories = itemObject.optDouble("calories", 0.0),
                                serving_size_g = itemObject.optDouble("serving_size_g", 100.0),
                                fat_total_g = itemObject.optDouble("fat_total_g", 0.0),
                                fat_saturated_g = itemObject.optDouble("fat_saturated_g", 0.0),
                                protein_g = itemObject.optDouble("protein_g", 0.0),
                                sodium_mg = itemObject.optDouble("sodium_mg", 0.0),
                                potassium_mg = itemObject.optDouble("potassium_mg", 0.0),
                                cholesterol_mg = itemObject.optDouble("cholesterol_mg", 0.0),
                                carbohydrates_total_g = itemObject.optDouble("carbohydrates_total_g", 0.0),
                                fiber_g = itemObject.optDouble("fiber_g", 0.0),
                                sugar_g = itemObject.optDouble("sugar_g", 0.0)
                            )
                        )
                    }

                    NutritionResponse(items)
                } else {
                    Log.e(TAG, "Error en la respuesta: $responseCode")
                    // Si hay error, devolvemos una respuesta vacía
                    NutritionResponse()
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error al obtener información nutricional", e)
                // Si hay excepción, devolvemos una respuesta vacía
                NutritionResponse()
            }
        }
    }

    // Obtener un alimento aleatorio de la lista
    fun getRandomHealthyFood(): String {
        return healthyFoods.random()
    }

    // Obtener el beneficio de un alimento según tipo de medicamento
    fun getFoodBenefit(food: String, medicationType: String?): String {
        return when {
            medicationType == null -> "Alimento rico en nutrientes"

            medicationType.contains("DIABETES", ignoreCase = true) -> {
                when (food) {
                    "apple" -> "Bajo índice glucémico, ideal para diabéticos"
                    "oats" -> "Liberación lenta de glucosa, controla azúcar en sangre"
                    "blueberries" -> "Antioxidantes que mejoran sensibilidad a insulina"
                    "spinach" -> "Alto en fibra, ayuda a controlar niveles de glucosa"
                    else -> "Buena opción para control glucémico"
                }
            }

            medicationType.contains("PRESSURE", ignoreCase = true) ||
                    medicationType.contains("HYPERTENSION", ignoreCase = true) -> {
                when (food) {
                    "banana" -> "Rico en potasio, ideal para presión arterial"
                    "spinach" -> "Bajo en sodio, alto en magnesio y potasio"
                    "avocado" -> "Grasas saludables que favorecen la salud cardiovascular"
                    "blueberries" -> "Flavonoides que mejoran la función vascular"
                    else -> "Buena opción para la salud cardiovascular"
                }
            }

            medicationType.contains("CHOLESTEROL", ignoreCase = true) -> {
                when (food) {
                    "oats" -> "Contiene beta-glucanos que reducen colesterol LDL"
                    "salmon" -> "Omega-3 que mejora perfil lipídico"
                    "walnuts" -> "Grasas saludables que reducen colesterol"
                    "avocado" -> "Aumenta colesterol HDL (bueno)"
                    else -> "Favorable para tu perfil lipídico"
                }
            }

            else -> "Alimento nutritivo que complementa tu tratamiento"
        }
    }
}