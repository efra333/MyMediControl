package com.example.mymedicontrol


enum class HistoryStatus {
    NORMAL,
    COMPLETED,
    MISSED,
    ALERT,
    DANGER
}