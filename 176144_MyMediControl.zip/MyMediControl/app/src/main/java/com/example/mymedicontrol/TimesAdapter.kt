package com.example.mymedicontrol



import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class TimesAdapter(
    private val times: List<String>,
    private val onItemClick: (Int) -> Unit
) : RecyclerView.Adapter<TimesAdapter.TimeViewHolder>() {

    class TimeViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvTime: TextView = itemView.findViewById(R.id.tvTime)
        val btnDelete: ImageButton = itemView.findViewById(R.id.btnDelete)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TimeViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_time, parent, false)
        return TimeViewHolder(view)
    }

    override fun onBindViewHolder(holder: TimeViewHolder, position: Int) {
        val time = times[position]
        holder.tvTime.text = time

        holder.btnDelete.setOnClickListener {
            onItemClick(position)
        }
    }

    override fun getItemCount(): Int = times.size
}