package com.example.mymedicontrol
import java.util.Date

data class MedicationDose(
    val id: Long = 0,
    val medicationId: Long,
    val takenAt: Date,
    val scheduled: Date,
    val status: String, // "TAKEN", "MISSED", "SKIPPED"
    val notes: String? = null
)