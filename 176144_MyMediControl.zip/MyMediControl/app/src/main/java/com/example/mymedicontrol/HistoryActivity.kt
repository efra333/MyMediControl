package com.example.mymedicontrol

import android.app.ProgressDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.Toolbar
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.tabs.TabLayout
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import kotlin.collections.ArrayList

class HistoryActivity : AppCompatActivity() {

    private lateinit var toolbar: Toolbar
    private lateinit var tabLayout: TabLayout
    private lateinit var frameEmpty: FrameLayout
    private lateinit var tvEmpty: TextView
    private lateinit var rvHistory: RecyclerView
    private lateinit var btnExport: Button

    private val medicationHistoryList = ArrayList<HistoryItem>()
    private val measurementHistoryList = ArrayList<HistoryItem>()
    private lateinit var historyAdapter: HistoryAdapter

    private lateinit var medicationDataSource: MedicationDataSource
    private lateinit var measurementDataSource: MeasurementDataSource

    private var currentTab = 0 // 0 = Medicamentos, 1 = Mediciones

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        try {
            Log.d("HistoryActivity", "Iniciando actividad de historial")

            // Inicializar vistas
            initializeViews()
            Log.d("HistoryActivity", "Vistas inicializadas")

            // Inicializar fuentes de datos
            initializeDataSources()
            Log.d("HistoryActivity", "Fuentes de datos inicializadas")

            // Configurar toolbar
            setupToolbar()
            Log.d("HistoryActivity", "Toolbar configurada")

            // Configurar TabLayout primero para que esté listo antes del RecyclerView
            setupTabLayout()
            Log.d("HistoryActivity", "TabLayout configurado")

            // Configurar RecyclerView
            setupRecyclerView()
            Log.d("HistoryActivity", "RecyclerView configurado")

            // Configurar botón de exportar
            setupExportButton()
            Log.d("HistoryActivity", "Botón de exportar configurado")

            // Cargar datos del historial
            loadHistoryData()
            Log.d("HistoryActivity", "Datos de historial cargados")

        } catch (e: Exception) {
            Log.e("HistoryActivity", "Error al inicializar la actividad", e)
            Toast.makeText(this, "Error al inicializar: ${e.message}", Toast.LENGTH_LONG).show()
            e.printStackTrace()
        }
    }

    // Se ejecuta cuando la actividad vuelve a primer plano
    override fun onResume() {
        super.onResume()
        // Actualizar el historial cada vez que la actividad vuelve a primer plano
        try {
            if (::medicationDataSource.isInitialized && ::measurementDataSource.isInitialized) {
                Log.d("HistoryActivity", "Recargando datos en onResume()")
                loadHistoryData()
            }
        } catch (e: Exception) {
            Log.e("HistoryActivity", "Error al recargar datos en onResume", e)
        }
    }

    private fun initializeDataSources() {
        try {
            medicationDataSource = MedicationDataSource(this)
            measurementDataSource = MeasurementDataSource(this)

            // Verificar la conexión a la base de datos
            val medicationsCount = medicationDataSource.getActiveMedications().size
            val dosesCount = medicationDataSource.getMedicationDoses().size

            Log.d("HistoryActivity", "Base de datos inicializada: $medicationsCount medicamentos activos, $dosesCount dosis registradas")
        } catch (e: Exception) {
            Log.e("HistoryActivity", "Error al inicializar fuentes de datos", e)
            Toast.makeText(this, "Error al conectar con la base de datos: ${e.message}", Toast.LENGTH_LONG).show()
            e.printStackTrace()

            // Crear instancias vacías para evitar errores de lateinit
            medicationDataSource = MedicationDataSource(this)
            measurementDataSource = MeasurementDataSource(this)
        }
    }

    private fun initializeViews() {
        toolbar = findViewById(R.id.toolbar)
        tabLayout = findViewById(R.id.tabLayout)
        frameEmpty = findViewById(R.id.frameEmpty)
        tvEmpty = findViewById(R.id.tvEmpty)
        rvHistory = findViewById(R.id.rvHistory)
        btnExport = findViewById(R.id.btnExport)
    }

    private fun setupToolbar() {
        setSupportActionBar(toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = "Historial"
    }

    private fun setupRecyclerView() {
        try {
            // Inicializar con lista vacía
            historyAdapter = HistoryAdapter(emptyList())
            rvHistory.layoutManager = LinearLayoutManager(this)
            rvHistory.adapter = historyAdapter

            Log.d("HistoryActivity", "RecyclerView configurado con adaptador")
        } catch (e: Exception) {
            Log.e("HistoryActivity", "Error al configurar RecyclerView", e)
            Toast.makeText(this, "Error al configurar lista: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setupTabLayout() {
        try {
            // Limpiar tabs existentes para evitar duplicados
            tabLayout.removeAllTabs()

            // Añadir las tabs
            tabLayout.addTab(tabLayout.newTab().setText("Medicamentos"))
            tabLayout.addTab(tabLayout.newTab().setText("Mediciones"))

            tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
                override fun onTabSelected(tab: TabLayout.Tab) {
                    currentTab = tab.position
                    Log.d("HistoryActivity", "Tab seleccionada: ${if (currentTab == 0) "Medicamentos" else "Mediciones"}")
                    updateHistoryList()
                }

                override fun onTabUnselected(tab: TabLayout.Tab) {}

                override fun onTabReselected(tab: TabLayout.Tab) {}
            })

            // Asegurarnos de que la primera tab esté seleccionada
            tabLayout.selectTab(tabLayout.getTabAt(0))
            currentTab = 0
        } catch (e: Exception) {
            Log.e("HistoryActivity", "Error al configurar TabLayout", e)
        }
    }

    private fun setupExportButton() {
        btnExport.setOnClickListener {
            exportToCsv()
        }
    }

    private fun loadHistoryData() {
        try {
            // Cargar historial de medicamentos
            loadMedicationHistory()
            Log.d("HistoryActivity", "Historial de medicamentos cargado: ${medicationHistoryList.size} elementos")

            // Cargar historial de mediciones
            loadMeasurementHistory()
            Log.d("HistoryActivity", "Historial de mediciones cargado: ${measurementHistoryList.size} elementos")

            // Ordenar por fecha más reciente primero
            medicationHistoryList.sortByDescending { it.date }
            measurementHistoryList.sortByDescending { it.date }

            // Actualizar la lista basada en la pestaña seleccionada
            updateHistoryList()

            // Para depuración
            debugMedicationHistory()
        } catch (e: Exception) {
            Log.e("HistoryActivity", "Error al cargar historial", e)
            Toast.makeText(this, "Error al cargar datos: ${e.message}", Toast.LENGTH_LONG).show()

            // Mostrar mensaje de error en la interfaz
            frameEmpty.visibility = View.VISIBLE
            rvHistory.visibility = View.GONE
            tvEmpty.text = "Error al cargar datos: ${e.message}"
        }
    }

    private fun loadMedicationHistory() {
        Log.d("HistoryActivity", "Iniciando carga de historial de medicamentos")
        medicationHistoryList.clear()
        try {
            val medicationDoses = medicationDataSource.getMedicationDoses()
            Log.d("HistoryActivity", "Dosis recuperadas: ${medicationDoses.size}")

            if (medicationDoses.isEmpty()) {
                Log.w("HistoryActivity", "No se encontraron dosis de medicamentos en la base de datos")
                return
            }

            // Procesar cada dosis
            for (dose in medicationDoses) {
                Log.d("HistoryActivity", "Procesando dosis ID: ${dose.id}, MedicationID: ${dose.medicationId}, Estado: ${dose.status}, Fecha: ${dose.takenAt}")

                // Obtener el medicamento asociado a esta dosis
                val medication = medicationDataSource.getMedicationById(dose.medicationId)

                if (medication != null) {
                    Log.d("HistoryActivity", "Medicamento encontrado: ${medication.name} ${medication.dose}")

                    // Crear elemento de historial
                    val historyItem = HistoryItem(
                        id = dose.id,
                        title = "${medication.name} ${medication.dose}",
                        value = when (dose.status) {
                            "TAKEN" -> "Tomado"
                            "MISSED" -> "Omitido"
                            "SKIPPED" -> "Saltado"
                            "SCHEDULED" -> "Programado"
                            else -> dose.status
                        },
                        date = dose.takenAt,
                        type = HistoryType.MEDICATION,
                        status = when (dose.status) {
                            "TAKEN" -> HistoryStatus.COMPLETED
                            "MISSED" -> HistoryStatus.MISSED
                            "SKIPPED" -> HistoryStatus.ALERT
                            "SCHEDULED" -> HistoryStatus.NORMAL
                            else -> HistoryStatus.NORMAL
                        }
                    )

                    // Añadir a la lista
                    medicationHistoryList.add(historyItem)
                    Log.d("HistoryActivity", "HistoryItem añadido: ${historyItem.title}, Estado: ${historyItem.status}, Valor: ${historyItem.value}")
                } else {
                    Log.e("HistoryActivity", "No se encontró el medicamento con ID: ${dose.medicationId}")
                }
            }

            Log.d("HistoryActivity", "Total de elementos en historial de medicamentos: ${medicationHistoryList.size}")
        } catch (e: Exception) {
            Log.e("HistoryActivity", "Error al cargar medicamentos", e)
            Toast.makeText(this, "Error al cargar medicamentos: ${e.message}", Toast.LENGTH_LONG).show()
            e.printStackTrace()
        }
    }

    private fun loadMeasurementHistory() {
        Log.d("HistoryActivity", "Iniciando carga de historial de mediciones")
        measurementHistoryList.clear()
        try {
            val measurements = measurementDataSource.getMeasurements()
            Log.d("HistoryActivity", "Mediciones recuperadas: ${measurements.size}")

            if (measurements.isEmpty()) {
                Log.w("HistoryActivity", "No se encontraron mediciones en la base de datos")
                return
            }

            for (measurement in measurements) {
                // Determinar el estado basado en los valores de medición
                val status = when {
                    measurement.type == "GLUCOSE" && (measurement.value.toFloatOrNull() ?: 0f) > 180 -> HistoryStatus.DANGER
                    measurement.type == "GLUCOSE" && (measurement.value.toFloatOrNull() ?: 0f) > 140 -> HistoryStatus.ALERT
                    measurement.type == "BLOOD_PRESSURE" && measurement.value.contains("/") -> {
                        val parts = measurement.value.split("/")
                        val systolic = parts.getOrNull(0)?.trim()?.toIntOrNull() ?: 0
                        val diastolic = parts.getOrNull(1)?.trim()?.toIntOrNull() ?: 0
                        when {
                            systolic > 160 || diastolic > 100 -> HistoryStatus.DANGER
                            systolic > 140 || diastolic > 90 -> HistoryStatus.ALERT
                            else -> HistoryStatus.NORMAL
                        }
                    }
                    else -> HistoryStatus.NORMAL
                }

                // Crear elemento de historial para la medición
                measurementHistoryList.add(
                    HistoryItem(
                        id = measurement.id,
                        title = when (measurement.type) {
                            "GLUCOSE" -> "Glucosa en sangre"
                            "BLOOD_PRESSURE" -> "Presión arterial"
                            "WEIGHT" -> "Peso"
                            else -> measurement.type
                        },
                        value = when (measurement.type) {
                            "GLUCOSE" -> "${measurement.value} mg/dL" + (if (!measurement.notes.isNullOrEmpty()) " - ${measurement.notes}" else "")
                            "BLOOD_PRESSURE" -> "${measurement.value} mmHg" + (if (!measurement.notes.isNullOrEmpty()) " - ${measurement.notes}" else "")
                            "WEIGHT" -> "${measurement.value} kg"
                            else -> measurement.value
                        },
                        date = measurement.datetime,
                        type = when (measurement.type) {
                            "GLUCOSE" -> HistoryType.GLUCOSE
                            "BLOOD_PRESSURE" -> HistoryType.BLOOD_PRESSURE
                            "WEIGHT" -> HistoryType.WEIGHT
                            else -> HistoryType.OTHER
                        },
                        status = status
                    )
                )
            }

            Log.d("HistoryActivity", "Total de elementos en historial de mediciones: ${measurementHistoryList.size}")
        } catch (e: Exception) {
            Log.e("HistoryActivity", "Error al cargar mediciones", e)
            Toast.makeText(this, "Error al cargar mediciones: ${e.message}", Toast.LENGTH_LONG).show()
            e.printStackTrace()
        }
    }

    private fun updateHistoryList() {
        try {
            // Seleccionar la lista correspondiente a la pestaña actual
            val currentList = if (currentTab == 0) medicationHistoryList else measurementHistoryList
            Log.d("HistoryActivity", "Actualizando lista para tab $currentTab (${if (currentTab == 0) "Medicamentos" else "Mediciones"}). Elementos: ${currentList.size}")

            if (currentList.isEmpty()) {
                // Mostrar mensaje de lista vacía
                Log.d("HistoryActivity", "La lista está vacía, mostrando mensaje")
                frameEmpty.visibility = View.VISIBLE
                rvHistory.visibility = View.GONE
                tvEmpty.text = if (currentTab == 0)
                    "No hay registros de medicamentos"
                else
                    "No hay registros de mediciones"
            } else {
                // Mostrar elementos en el RecyclerView
                Log.d("HistoryActivity", "La lista tiene ${currentList.size} elementos, mostrando RecyclerView")
                frameEmpty.visibility = View.GONE
                rvHistory.visibility = View.VISIBLE
                historyAdapter.updateData(currentList)
            }
        } catch (e: Exception) {
            Log.e("HistoryActivity", "Error al actualizar lista de historial", e)
            Toast.makeText(this, "Error al mostrar datos: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    // Método de depuración para verificar el contenido de la base de datos
    private fun debugMedicationHistory() {
        try {
            // Verificar medicamentos activos
            val activeMedications = medicationDataSource.getActiveMedications()
            Log.d("DatabaseCheck", "Total de medicamentos activos: ${activeMedications.size}")

            // Listar todos los medicamentos activos
            for (med in activeMedications) {
                Log.d("DatabaseCheck", "Medicamento: ID=${med.id}, Nombre=${med.name}, Dosis=${med.dose}, Tipo=${med.type}, Activo=${med.active}")
            }

            // Verificar todas las dosis
            val allDoses = medicationDataSource.getMedicationDoses()
            Log.d("DatabaseCheck", "Total de dosis en la base de datos: ${allDoses.size}")

            // Listar todas las dosis
            for (dose in allDoses) {
                val medicationName = medicationDataSource.getMedicationById(dose.medicationId)?.name ?: "Desconocido"
                Log.d("DatabaseCheck", "Dosis: ID=${dose.id}, MedicationID=${dose.medicationId} (${medicationName}), Estado=${dose.status}, Fecha=${dose.takenAt}")
            }

            // Verificar dosis sin medicamento (huérfanas)
            val orphanDoses = allDoses.filter { dose ->
                medicationDataSource.getMedicationById(dose.medicationId) == null
            }

            if (orphanDoses.isNotEmpty()) {
                Log.e("DatabaseCheck", "¡ALERTA! Hay ${orphanDoses.size} dosis huérfanas (sin medicamento asociado)")
                for (dose in orphanDoses) {
                    Log.e("DatabaseCheck", "Dosis huérfana: ID=${dose.id}, MedicamentoID=${dose.medicationId}")
                }
            }
        } catch (e: Exception) {
            Log.e("DatabaseCheck", "Error al verificar contenido de base de datos", e)
        }
    }

    private fun exportToCsv() {
        try {
            Log.d("HistoryActivity", "Iniciando exportación a CSV")

            // Mostrar progreso
            val progressDialog = ProgressDialog(this)
            progressDialog.setMessage("Generando archivo CSV...")
            progressDialog.setCancelable(false)
            progressDialog.show()

            // Crear directorio si no existe
            val csvFolder = File(getExternalFilesDir(null), "MediControl")
            if (!csvFolder.exists()) {
                csvFolder.mkdirs()
                Log.d("HistoryActivity", "Directorio para CSV creado: ${csvFolder.absolutePath}")
            }

            // Crear nombre de archivo con fecha y hora
            val dateFormat = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault())
            val timestamp = dateFormat.format(Date())
            val csvFile = File(csvFolder, "historial_medicontrol_$timestamp.csv")
            Log.d("HistoryActivity", "Archivo CSV destino: ${csvFile.absolutePath}")

            // Generar el CSV en un hilo secundario para no bloquear la UI
            Thread {
                try {
                    // Generar el CSV
                    csvFile.createNewFile()
                    val fileWriter = FileOutputStream(csvFile).writer()

                    // Añadir cabecera con información general
                    val preferences = getSharedPreferences("MediControlPrefs", MODE_PRIVATE)
                    val userName = preferences.getString("userName", "Usuario")
                    val userCondition = preferences.getString("userCondition", "No especificada")

                    fileWriter.write("MediControl - Exportación de Historial\n")
                    fileWriter.write("Fecha de exportación: ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date())}\n")
                    fileWriter.write("Paciente: $userName\n")
                    fileWriter.write("Condición médica: $userCondition\n\n")

                    // Decidir qué datos exportar según la pestaña actual
                    if (currentTab == 0) {
                        // Exportar historial de medicamentos
                        fileWriter.write("HISTORIAL DE MEDICAMENTOS\n\n")

                        // Escribir encabezados
                        fileWriter.write("Medicamento,Estado,Fecha,Hora\n")

                        // Formato de fecha para mostrar
                        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

                        // Escribir datos
                        for (item in medicationHistoryList) {
                            val date = dateFormat.format(item.date)
                            val time = timeFormat.format(item.date)
                            // Escapar comillas para evitar problemas en el CSV
                            val safeTitle = item.title.replace("\"", "\"\"")
                            val safeValue = item.value.replace("\"", "\"\"")
                            fileWriter.write("\"$safeTitle\",\"$safeValue\",\"$date\",\"$time\"\n")
                        }

                        // Añadir leyenda
                        fileWriter.write("\nLEYENDA:\n")
                        fileWriter.write("Tomado: El medicamento fue administrado correctamente\n")
                        fileWriter.write("Omitido: El medicamento no fue administrado\n")
                        fileWriter.write("Saltado: El medicamento fue saltado intencionalmente\n")
                        fileWriter.write("Programado: El medicamento está programado para ser tomado\n")
                    } else {
                        // Exportar historial de mediciones
                        fileWriter.write("HISTORIAL DE MEDICIONES\n\n")

                        // Escribir encabezados
                        fileWriter.write("Tipo,Valor,Fecha,Hora\n")

                        // Formato de fecha para mostrar
                        val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())

                        // Escribir datos
                        for (item in measurementHistoryList) {
                            val date = dateFormat.format(item.date)
                            val time = timeFormat.format(item.date)
                            // Escapar comillas para evitar problemas en el CSV
                            val safeTitle = item.title.replace("\"", "\"\"")
                            val safeValue = item.value.replace("\"", "\"\"")
                            fileWriter.write("\"$safeTitle\",\"$safeValue\",\"$date\",\"$time\"\n")
                        }

                        // Añadir información sobre rangos normales
                        fileWriter.write("\nRANGOS NORMALES:\n")
                        fileWriter.write("Glucosa en sangre: <140 mg/dL en ayunas\n")
                        fileWriter.write("Presión arterial: <140/90 mmHg\n")
                    }

                    // Cerrar el archivo
                    fileWriter.close()
                    Log.d("HistoryActivity", "CSV generado correctamente")

                    // Actualizar UI en el hilo principal
                    runOnUiThread {
                        progressDialog.dismiss()
                        Toast.makeText(this@HistoryActivity, "CSV generado exitosamente", Toast.LENGTH_LONG).show()

                        // Preguntar al usuario si desea abrir/compartir el archivo
                        AlertDialog.Builder(this@HistoryActivity)
                            .setTitle("Archivo CSV Generado")
                            .setMessage("El archivo CSV ha sido guardado en:\n${csvFile.absolutePath}\n\n¿Qué deseas hacer ahora?")
                            .setPositiveButton("Abrir") { _, _ -> openCsvFile(csvFile) }
                            .setNeutralButton("Compartir") { _, _ -> shareCsvFile(csvFile) }
                            .setNegativeButton("Cerrar", null)
                            .show()
                    }
                } catch (e: Exception) {
                    Log.e("HistoryActivity", "Error al generar CSV", e)
                    runOnUiThread {
                        progressDialog.dismiss()
                        Toast.makeText(
                            this@HistoryActivity,
                            "Error al generar CSV: ${e.message}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }.start()

        } catch (e: Exception) {
            Log.e("HistoryActivity", "Error en exportación", e)
            Toast.makeText(this, "Error al exportar: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun openCsvFile(file: File) {
        try {
            Log.d("HistoryActivity", "Intentando abrir el archivo CSV: ${file.absolutePath}")

            // Crear URI para el archivo utilizando FileProvider
            val uri = FileProvider.getUriForFile(
                this,
                "${applicationContext.packageName}.fileprovider",
                file
            )

            // Crear intent para abrir CSV
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "text/csv")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            // Verificar si hay aplicaciones disponibles para abrir CSV
            if (intent.resolveActivity(packageManager) != null) {
                startActivity(intent)
            } else {
                // Intentar con un intent más genérico si no hay aplicación específica para CSV
                val genericIntent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, "text/plain")
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }

                if (genericIntent.resolveActivity(packageManager) != null) {
                    startActivity(genericIntent)
                } else {
                    Toast.makeText(this, "No hay aplicaciones instaladas para abrir archivos CSV", Toast.LENGTH_LONG).show()
                    Log.w("HistoryActivity", "No hay aplicaciones instaladas para abrir archivos CSV")
                }
            }
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "No hay aplicaciones instaladas para abrir archivos CSV", Toast.LENGTH_LONG).show()
            Log.e("HistoryActivity", "Error: No hay aplicaciones para abrir CSV", e)
        } catch (e: Exception) {
            Toast.makeText(this, "Error al abrir el CSV: ${e.message}", Toast.LENGTH_LONG).show()
            Log.e("HistoryActivity", "Error al abrir el CSV", e)
        }
    }

    private fun shareCsvFile(file: File) {
        try {
            Log.d("HistoryActivity", "Intentando compartir el archivo CSV: ${file.absolutePath}")

            // Crear URI para el archivo utilizando FileProvider
            val uri = FileProvider.getUriForFile(
                this,
                "${applicationContext.packageName}.fileprovider",
                file
            )

            // Crear intent para compartir
            val shareIntent = Intent().apply {
                action = Intent.ACTION_SEND
                putExtra(Intent.EXTRA_STREAM, uri)
                type = "text/csv"
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            startActivity(Intent.createChooser(shareIntent, "Compartir historial"))

        } catch (e: Exception) {
            Toast.makeText(this, "Error al compartir el archivo: ${e.message}", Toast.LENGTH_LONG).show()
            Log.e("HistoryActivity", "Error al compartir el archivo", e)
        }
    }

    // Botón de regreso
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            onBackPressed()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    // Si hay algún método limpieza o liberación de recursos, añadirlo aquí
    override fun onDestroy() {
        super.onDestroy()
        // Si es necesario, liberar recursos
    }
}